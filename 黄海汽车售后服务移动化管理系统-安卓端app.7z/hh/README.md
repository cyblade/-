## Android RecyclerView Demo
This is just an Android RecyclerView Demo from my tutorial. It's in Chinese.
The tutorial's address is here.
https://www.jianshu.com/p/4782824d9307

Down below is what the demo looks like.

![](https://upload-images.jianshu.io/upload_images/11181600-92ea217674140c15.png)
