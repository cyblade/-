package com.example.takevideo.record.landscapevideocamera;

/**
 * Created by Jeroen Mols on 10/09/15.
 */
public class AlreadyUsedException extends Exception {
}
