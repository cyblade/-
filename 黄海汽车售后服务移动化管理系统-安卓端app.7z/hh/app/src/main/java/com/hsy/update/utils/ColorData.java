package com.hsy.update.utils;

import android.graphics.Color;

/**
 * Created by huagnshuyuan on 2017/3/16.
 */

public class ColorData {
    /**
     * 对话框字体主题色
     */

    public static int RED_THEME = Color.parseColor("#eb2127");
}
