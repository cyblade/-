package com.hsy.update.view;
/**
 * Created by huagnshuyuan on 2017/3/16.
 */
public interface OnBtnClickL {
	void onBtnClick();
}
