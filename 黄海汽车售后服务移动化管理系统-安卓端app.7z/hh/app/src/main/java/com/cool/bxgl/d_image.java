package com.cool.bxgl;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

import java.io.FileNotFoundException;

public class d_image extends AppCompatActivity {
    ImageView imageDetail;
    String imageId;
    public Uri aa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.d_image);


        imageId = getIntent().getStringExtra("imageid");
        aa = Uri.parse((String) imageId);
        try {
            Bitmap bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(aa));
            imageDetail = (ImageView) findViewById(R.id.imageView1);
            imageDetail.setImageBitmap(bitmap);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }


        ImageButton back = (ImageButton) findViewById(R.id.yt_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                d_image.this.finish();
            }
        });

    }
}


