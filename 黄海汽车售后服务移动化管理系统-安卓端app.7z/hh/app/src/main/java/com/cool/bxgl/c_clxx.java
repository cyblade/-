package com.cool.bxgl;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class c_clxx extends AppCompatActivity {
    public String wtsh, fwzh, xllb_dm, GetEmail, wcid, Getdph, Getcph, ReturnResult, a = "1" , ReturnResult2;
    public List<Map<String, Object>> listItems = new ArrayList<>();
    private RecyclerView recyclerView;
    private Handler mHandler = new Handler();
    ImageButton back;
    public TextView dph0,xh0,clys0,fdjh0,bsxh0,scrq0,lzrq0,yhmc0,yhdh0,lxr0,lxrdh0,cph0;

    private ProgressDialog pd;
    public static String URL2 = "http://47.93.46.72/BxdService.asmx?op=AddBxd";
    public static String SOAP_ACTION_clx = "http://tempuri.org/AddBxd";
    public static String METHOD_NAME_clx = "AddBxd";


    public static String URL = "http://47.93.46.72/BxdService.asmx?op=getCarInfo";
    public static String NAMESPACE = "http://tempuri.org/";
    public static String SOAP_ACTION_Bxd = "http://tempuri.org/getCarInfo";
    public static String METHOD_NAME_Bxd = "getCarInfo";


    public static String URL3 = "http://47.93.46.72/BxdService.asmx?op=GetWtsLb";
    public static String NAMESPACE3 = "http://tempuri.org/";
    public static String SOAP_ACTION3 = "http://tempuri.org/GetWtsLb";
    public static String METHOD_NAME3 = "GetWtsLb";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.c_clxx);
        wcid = getIntent().getStringExtra("wcid");
        GetEmail = getIntent().getStringExtra("GetEmail");
        Getdph = getIntent().getStringExtra("Getdph");
        recyclerView = (RecyclerView) findViewById(R.id.clxx_recyclerview);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.addItemDecoration(new c_Decoration(2));
        dph0 = (TextView) findViewById(R.id.clxx_dph);
        xh0 = (TextView) findViewById(R.id.clxx_xh);
        clys0 = (TextView) findViewById(R.id.clxx_clys);
        fdjh0 = (TextView) findViewById(R.id.clxx_fdjh);
        bsxh0 = (TextView) findViewById(R.id.clxx_bsxh);
        scrq0 = (TextView) findViewById(R.id.clxx_scrq);
        lzrq0 = (TextView) findViewById(R.id.clxx_gcrq);
        yhmc0 = (TextView) findViewById(R.id.clxx_yhmc);
        yhdh0 = (TextView) findViewById(R.id.clxx_yhdh);
        lxr0 = (TextView) findViewById(R.id.clxx_lxy);
        lxrdh0 = (TextView) findViewById(R.id.clxx_lxrdh);
        cph0 = (TextView) findViewById(R.id.clxx_cph);
        Button jrgzlb = (Button) findViewById(R.id.jrgzlb);
        back = (ImageButton) findViewById(R.id.clxxx_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                c_clxx.this.finish();
            }
        });
        new c_clxx.MyAsyncTaskwts().execute(GetEmail, Getdph);
        new c_clxx.MyAsyncTask0().execute(GetEmail, Getdph);
        listItems = new ArrayList<>();
        jrgzlb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final c_clxx_dialog dialog = new c_clxx_dialog(c_clxx.this, R.layout.c_clxx_dialog);
                dialog.show();
                TextView tvCancel = (TextView) dialog.findViewById(R.id.cancel);
                TextView tvOk = (TextView) dialog.findViewById(R.id.ok);
                tvOk.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        new MyAsyncTaskadd().execute(GetEmail, Getdph, Getcph, "4", wcid);
                        dialog.dismiss();
                    }
                });
                tvCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
            }
        });
    }

    private class MyAsyncTaskadd extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {

            SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME_clx);

            PropertyInfo infoEmail2 = new PropertyInfo();
            infoEmail2.setName("username");
            infoEmail2.setType(String.class);
            infoEmail2.setValue(strings[0].toString());
            request.addProperty(infoEmail2);

            PropertyInfo infost2 = new PropertyInfo();
            infost2.setName("dph");
            infost2.setType(String.class);
            infost2.setValue(strings[1].toString());
            request.addProperty(infost2);

            PropertyInfo infodp2 = new PropertyInfo();
            infodp2.setName("cph");
            infodp2.setType(String.class);
            infodp2.setValue(strings[2].toString());
            request.addProperty(infodp2);

            PropertyInfo in2 = new PropertyInfo();
            in2.setName("yzm");
            in2.setType(String.class);
            in2.setValue(strings[3].toString());
            request.addProperty(in2);

            PropertyInfo i = new PropertyInfo();
            i.setName("wcfw_id");
            i.setType(String.class);
            i.setValue(strings[4].toString());
            request.addProperty(i);

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.dotNet = true;
            envelope.setOutputSoapObject(request);
            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL2);
            try {
                //Thread.sleep(5000);
                //  AndroidHttpTransport
                //this is the actual part that will call the webservice
                androidHttpTransport.call(SOAP_ACTION_clx, envelope);
                //  SoapPrimitive resultee=(SoapPrimitive)envelope.getResponse();
                // Get the SoapResult from the envelope body.
                SoapObject result = (SoapObject) envelope.bodyIn;
                ReturnResult2 = result.getProperty(0).toString();
            } catch (Exception e) {
                e.printStackTrace();
                return e.toString();
            }
            return ReturnResult2;
        }


        protected void onPreExecute() {
            pd = ProgressDialog.show(c_clxx.this, "", "正在新建");
        }

        protected void onPostExecute(String result) {
            pd.cancel();
            if (result.equals("success")) {
                Toast.makeText(c_clxx.this, "新建成功", Toast.LENGTH_SHORT).show();
                try {
                    Intent intent = new Intent(c_clxx.this, c_bxgl.class);
                    intent.putExtra("GetEmail", GetEmail);
                    startActivity(intent);
                    finish();
                } catch (Exception E) {
                    String aa = E.toString();
                }
            } else {
                Toast.makeText(getApplicationContext(), "新建失败", Toast.LENGTH_LONG).show();
                // Hide the progress bar
                //  progressBar.setVisibility(View.GONE);
            }
        }
    }

    private class MyAsyncTask0 extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {

            SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME_Bxd);
            PropertyInfo infodph = new PropertyInfo();
            infodph.setName("username");
            infodph.setType(String.class);
            infodph.setValue(strings[0].toString());
            request.addProperty(infodph);

            PropertyInfo infoEmail = new PropertyInfo();
            infoEmail.setName("dph");
            infoEmail.setType(String.class);
            infoEmail.setValue(strings[1].toString());
            request.addProperty(infoEmail);

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.dotNet = true;
            envelope.setOutputSoapObject(request);
            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
            try {
                //Thread.sleep(5000);
                //  AndroidHttpTransport
                //this is the actual part that will call the webservice
                androidHttpTransport.call(SOAP_ACTION_Bxd, envelope);
                //  SoapPrimitive resultee=(SoapPrimitive)envelope.getResponse();
                // Get the SoapResult from the envelope body.
                SoapObject result = (SoapObject) envelope.bodyIn;
                ReturnResult = result.getProperty(0).toString();
            } catch (Exception e) {
                e.printStackTrace();
                return e.toString();
            }
            return ReturnResult;
        }

        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    JSONArray array = new JSONArray(result);
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);
                        dph0.setText(object.getString("dph"));
                        xh0.setText(object.getString("xh"));
                        clys0.setText(object.getString("clys"));
                        fdjh0.setText(object.getString("fdjh"));
                        bsxh0.setText(object.getString("bsxh"));
                        scrq0.setText(object.getString("scrq"));
                        lzrq0.setText(object.getString("lzrq"));
                        yhmc0.setText(object.getString("yhmc"));
                        yhdh0.setText(object.getString("yhdh"));
                        lxr0.setText(object.getString("lxr"));
                        lxrdh0.setText(object.getString("lxrdh"));
                        cph0.setText(object.getString("cph"));
                        Getcph = cph0.getText().toString();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private class MyAsyncTaskwts extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {

            SoapObject request = new SoapObject(NAMESPACE3, METHOD_NAME3);
            PropertyInfo infodph = new PropertyInfo();
            infodph.setName("username");
            infodph.setType(String.class);
            infodph.setValue(strings[0].toString());
            request.addProperty(infodph);

            PropertyInfo infoEmail = new PropertyInfo();
            infoEmail.setName("dph");
            infoEmail.setType(String.class);
            infoEmail.setValue(strings[1].toString());
            request.addProperty(infoEmail);

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.dotNet = true;
            envelope.setOutputSoapObject(request);
            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL3);
            try {
                //Thread.sleep(5000);
                //  AndroidHttpTransport
                //this is the actual part that will call the webservice
                androidHttpTransport.call(SOAP_ACTION3, envelope);
                //  SoapPrimitive resultee=(SoapPrimitive)envelope.getResponse();
                // Get the SoapResult from the envelope body.
                SoapObject result = (SoapObject) envelope.bodyIn;
                ReturnResult = result.getProperty(0).toString();
            } catch (Exception e) {
                e.printStackTrace();
                return e.toString();
            }
            return ReturnResult;
        }

        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    JSONArray array = new JSONArray(result);
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);
                        wtsh = object.getString("wtsh");
                        fwzh = object.getString("fwzh");
                        xllb_dm = object.getString("xllb_dm");
                        Map<String, Object> map = new HashMap<>();
                        map.put("wtsh", wtsh);
                        map.put("fwzh", fwzh);
                        map.put("xllb_dm", xllb_dm);
                        map.put("username", GetEmail);
                        listItems.add(map);
                    }
                    recyclerView.addItemDecoration(new DividerItemDecoration(
                            c_clxx.this, DividerItemDecoration.VERTICAL));
                    c_clxx_Adapter recy = new c_clxx_Adapter(listItems, c_clxx.this);
                    //设置布局显示格式
                    recyclerView.setLayoutManager(new LinearLayoutManager(c_clxx.this));
                    recyclerView.setAdapter(recy);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}