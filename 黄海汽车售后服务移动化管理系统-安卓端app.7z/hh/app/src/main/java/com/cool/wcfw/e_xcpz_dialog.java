package com.cool.wcfw;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.WindowManager;

import com.cool.bxgl.R;

public class e_xcpz_dialog extends Dialog {
    private Context context;
    private int resId;



    public e_xcpz_dialog(Context context, int resLayout) {
        this(context, 0, 0);
    }

    public e_xcpz_dialog(Context context, int themeResId, int resLayout) {
        super(context, themeResId);
        this.context = context;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.e_xcpz_dialog);
        WindowManager m = getWindow().getWindowManager();
        Display d = m.getDefaultDisplay();
        WindowManager.LayoutParams p = getWindow().getAttributes();
        Point size = new Point();
        d.getSize(size);
        getWindow().setAttributes(p);
    }


}




