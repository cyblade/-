package com.cool.bxgl;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


class c_gzlb_Adapter extends RecyclerView.Adapter<c_gzlb_Adapter.MyViewHolder> {
    private Context context;
    public List<Map<String, Object>> list = new ArrayList<>();
    private ButtonInterface buttonInterface;
    public LayoutInflater inflater;
    String show;

    public c_gzlb_Adapter(List<Map<String, Object>> list, Context context) {
        this.list = list;
        this.context = context;
        inflater = LayoutInflater.from(context);
    }

    public void buttonSetOnclick(c_gzlb_Adapter.ButtonInterface buttonInterface) {
        this.buttonInterface = buttonInterface;
    }

    public interface ButtonInterface {
        public void onclick(View view, int position);
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.c_gzlb_item, null);
        MyViewHolder viewHolder = new MyViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        holder.mgzsm.setText(list.get(position).get("gzsm").toString());
        holder.msxr.setText(list.get(position).get("sxr").toString());
        holder.msxrdh.setText(list.get(position).get("sxrdh").toString());
        holder.mspbg.setText(list.get(position).get("spbg").toString());
        holder.mkhts.setText(list.get(position).get("khts").toString());
        holder.mwcbg.setText(list.get(position).get("wcbg").toString());
        holder.mct.setText(list.get(position).get("create_time").toString());
        holder.mgzid.setText(list.get(position).get("id").toString());
        holder.musername.setText(list.get(position).get("username").toString());
        holder.mshzt.setText(list.get(position).get("shzt").toString());
        holder.mfszt.setText(list.get(position).get("fszt").toString());


        String fszt3 = holder.mfszt.getText().toString();
        if (fszt3.equals("审核通过")) {
            holder.mfszt.setTextColor(Color.parseColor("#0066cc"));
        } else if (fszt3.equals("审核不通过")) {
            holder.mfszt.setTextColor(Color.parseColor("#e60000"));
        } else if (fszt3.equals("批注")) {
            holder.mfszt.setTextColor(Color.parseColor("#33cc33"));
        } else {
            holder.mfszt.setTextColor(Color.parseColor("#000000"));
        }
        ;
        String shzt3 = holder.mshzt.getText().toString();
        if (shzt3.equals("审核通过")) {
            holder.mshzt.setTextColor(Color.parseColor("#0066cc"));
            show = "1";
        } else if (shzt3.equals("审核不通过")) {
            holder.mshzt.setTextColor(Color.parseColor("#e60000"));
        } else if (shzt3.equals("批注")) {
            holder.mshzt.setTextColor(Color.parseColor("#33cc33"));
        } else {
            holder.mshzt.setTextColor(Color.parseColor("#000000"));
        }
        ;
        holder.tv_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id9 = holder.mgzid.getText().toString();
                String fszt9 = holder.mfszt.getText().toString();
                String shzt9 = holder.mshzt.getText().toString();
                String username9 = holder.musername.getText().toString();
                Intent intx = new Intent(context, c_gzsm_gzzp.class);
                intx.putExtra("id", id9);
                intx.putExtra("username", username9);
                intx.putExtra("fszt", fszt9);
                intx.putExtra("shzt", shzt9);
                if (show != null) {
                    intx.putExtra("show", show);
                }
                ;
                context.startActivity(intx);
            }
        });
        holder.gzlbItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String gzsm9 = holder.mgzsm.getText().toString();
                String wcbg9 = holder.mwcbg.getText().toString();
                String spbg9 = holder.mspbg.getText().toString();
                String khts9 = holder.mkhts.getText().toString();
                String sxr9 = holder.msxr.getText().toString();
                String sxrdh9 = holder.msxrdh.getText().toString();
                String id9 = holder.mgzid.getText().toString();
                String username9 = holder.musername.getText().toString();
                String fszt9 = holder.mfszt.getText().toString();
                String shzt9 = holder.mshzt.getText().toString();
                Intent intent = new Intent(context, c_gzsm.class);
                intent.putExtra("show", show);
                intent.putExtra("gzsm", gzsm9);
                intent.putExtra("sxr", sxr9);
                intent.putExtra("sxrdh", sxrdh9);
                intent.putExtra("spbg", spbg9);
                intent.putExtra("khts", khts9);
                intent.putExtra("wcbg", wcbg9);
                intent.putExtra("id", id9);
                intent.putExtra("username", username9);
                intent.putExtra("fszt", fszt9);
                intent.putExtra("shzt", shzt9);
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView mct, mgzsm, mspbg, msxr, msxrdh, mfszt, mshzt, mwcbg, mkhts, mgzid, musername;
        Button tv_delete;
        private RelativeLayout gzlbItem;

        //因为删除有可能会删除中间条目，然后会造成角标越界，所以必须整体刷新一下！
        public MyViewHolder(View view) {
            super(view);

            gzlbItem = itemView.findViewById(R.id.gzlb_item);
            mct = itemView.findViewById(R.id.gzsm_cjsj);
            mgzid = itemView.findViewById(R.id.gzid);
            mgzsm = itemView.findViewById(R.id.gzlb_gzsm);
            msxr = itemView.findViewById(R.id.gzlb_sxrxm);
            msxrdh = itemView.findViewById(R.id.gzlb_dh);
            mwcbg = itemView.findViewById(R.id.gzlb_wcbg);
            mkhts = itemView.findViewById(R.id.gzlb_khts);
            mspbg = itemView.findViewById(R.id.gzlb_spbg);
            musername = itemView.findViewById(R.id.gzlb_username);
            mfszt = itemView.findViewById(R.id.gzlb_fszt);
            mshzt = itemView.findViewById(R.id.gzlb_cszt);

            tv_delete = (Button) view.findViewById(R.id.tv_delete);
        }
    }
}
