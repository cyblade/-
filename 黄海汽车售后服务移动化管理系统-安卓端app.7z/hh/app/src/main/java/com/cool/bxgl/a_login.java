package com.cool.bxgl;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

public class a_login extends AppCompatActivity {
    public static final String REMEMBER_PASSWORD = "remember_password";
    public static final String ACCOUNT = "account";
    public static final String PASSWORD = "password";
    private SharedPreferences spf;
    private SharedPreferences.Editor editor;
    private SharedPreferences sp=null;
    private boolean isRemember;
    @Override
    public void onBackPressed() {
    }
    // 用来计算返回键的点击间隔时间
    private long exitTime = 0;
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK
                && event.getAction() == KeyEvent.ACTION_DOWN) {
            if ((System.currentTimeMillis() - exitTime) > 2000) {
                //弹出提示，可以有多种方式
                Toast.makeText(getApplicationContext(), "再按一次退出程序", Toast.LENGTH_SHORT).show();
                exitTime = System.currentTimeMillis();
            } else {
                finish();
            }
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    Button btn_Login;
    EditText ET_Email,ET_Password;
    String EmailStr,PasswordStr,ReturnResult;
    private ProgressDialog pd;

    /** Web Service */
    public static String URL = "http://47.93.46.72/UserService.asmx?op=login";
    public static String NAMESPACE = "http://tempuri.org/";
    /** Login */
    public static String SOAP_ACTION_Login = "http://tempuri.org/login";
    public static String METHOD_NAME_Login = "login";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a_login);
        ET_Email=(EditText)findViewById(R.id.ETEmail);
        ET_Password=(EditText)findViewById(R.id.ETPassword);
        ET_Password.setTransformationMethod(PasswordTransformationMethod.getInstance());
        btn_Login=(Button)findViewById(R.id.login);

        //获取SharedPreferences对象
        spf = PreferenceManager.getDefaultSharedPreferences(this);
        isRemember = spf.getBoolean(REMEMBER_PASSWORD, false);

        String account = spf.getString(ACCOUNT, "");
        String passworrd = spf.getString(PASSWORD, "");
        ET_Email.setText(account);
        ET_Password.setText(passworrd);




        btn_Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EmailStr=ET_Email.getText().toString();
                PasswordStr=ET_Password.getText().toString();
                if(EmailStr.isEmpty()||PasswordStr.isEmpty()){
                    Toast.makeText(a_login.this,"请输入用户名或密码", Toast.LENGTH_SHORT).show();
                }
                else{
                    new MyAsyncTask().execute(EmailStr,PasswordStr);
                }
            }
        });
    }
    private class MyAsyncTask extends AsyncTask<String,Void,String> {


        @Override
        protected String doInBackground(String... strings) {

            SoapObject request = new SoapObject(NAMESPACE,METHOD_NAME_Login);

            PropertyInfo infoEmail=new PropertyInfo();
            infoEmail.setName("username");
            infoEmail.setType(String.class);
            infoEmail.setValue(strings[0].toString());
            request.addProperty(infoEmail);

            PropertyInfo infoPassword=new PropertyInfo();
            infoPassword.setName("password");
            infoPassword.setType(String.class);
            infoPassword.setValue(strings[1].toString());

            //Use this to add parameters
            request.addProperty(infoPassword);
            // request.addProperty("password", voids[1].toString());

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.dotNet = true;
            envelope.setOutputSoapObject(request);

            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
            try {
                androidHttpTransport.call(SOAP_ACTION_Login, envelope);
                SoapObject result = (SoapObject) envelope.bodyIn;
                if (result != null) {
                    //Get the first property and change the label text
                    ReturnResult = result.getProperty(0).toString();
//String msg=resultee.toString();
                    //    Toast.makeText(LoginActivity.this, msg, Toast.LENGTH_LONG).show();
                }
            } catch (Exception e) {
                e.printStackTrace();
                return e.toString();
            }
            return ReturnResult;
        }
        protected void onPreExecute() {
            pd = ProgressDialog.show(a_login.this, "", "加载中，请稍后");
        }
        protected void onPostExecute(String result) {
            pd.cancel();
            if(result.equals("true")){
                Toast.makeText(a_login.this, "登陆成功", Toast.LENGTH_SHORT).show();
                Intent MyHomeActivity=new Intent(a_login.this,a_menu.class);
                MyHomeActivity.putExtra("GetEmail",EmailStr);
                editor = spf.edit();
                //检查复选框是否选中，选中则向SharedPreferences.Editor 对象中添加数据
                editor.putBoolean(REMEMBER_PASSWORD, true);
                editor.putString(ACCOUNT, EmailStr);
                editor.putString(PASSWORD, PasswordStr);
                editor.apply(); //提交数据
                startActivity(MyHomeActivity);
                finish();
            }
            else {
                Toast.makeText(getApplicationContext(), "用户名或密码错误", Toast.LENGTH_LONG).show();
                // Hide the progress bar
                //  progressBar.setVisibility(View.GONE);
            }
        }

    }
}