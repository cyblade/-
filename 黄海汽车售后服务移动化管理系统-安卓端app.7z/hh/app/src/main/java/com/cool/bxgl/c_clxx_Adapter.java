package com.cool.bxgl;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class c_clxx_Adapter extends RecyclerView.Adapter<c_clxx_Adapter.ViewHolder> {
    private Context context;
    public List<Map<String,Object>>list = new ArrayList<>();
    private ButtonInterface buttonInterface;
    public LayoutInflater inflater;
    public c_clxx_Adapter(List<Map<String,Object>> list, Context context) {
        this.list=list;
        this.context = context;
        inflater=LayoutInflater.from(context);
    }
    public void buttonSetOnclick(c_clxx_Adapter.ButtonInterface buttonInterface){
        this.buttonInterface=buttonInterface;
    }
    public interface ButtonInterface{
        public void onclick(View view, int position);
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= inflater.inflate(R.layout.c_clxx_item,null);
        ViewHolder viewHolder=new ViewHolder(view);
        return viewHolder;
    }
    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        holder.mwtsh.setText(list.get(position).get("wtsh").toString());
        holder.mfwzh.setText(list.get(position).get("fwzh").toString());
        holder.mxllb.setText(list.get(position).get("xllb_dm").toString());
        holder.musername.setText(list.get(position).get("username").toString());
        holder.cllbItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username9 = holder.musername.getText().toString();
                String wtsh9 = holder.mwtsh.getText().toString();
                Intent intent9 = new Intent(context, c_wtswxxm.class);
                intent9.putExtra("username",username9);
                intent9.putExtra("wtsh", wtsh9);
                context.startActivity(intent9);
            }
        });
    }
    @Override
    public int getItemCount() { return list.size(); }
    class ViewHolder extends RecyclerView.ViewHolder {
        private RelativeLayout cllbItem;
        public TextView mwtsh,mfwzh,mxllb,musername;
        ViewHolder(View itemView) {
            super(itemView);
            mwtsh = itemView.findViewById(R.id.cllb_1_dph);
            mfwzh = itemView.findViewById(R.id.cllb_1_cph);
            mxllb= itemView.findViewById(R.id.cllb_1_clys);
            musername = itemView.findViewById(R.id.cllb_un);
            cllbItem = itemView.findViewById(R.id.clxxx_item);
        }
    }
}



