package com.cool.wcfw;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DataBaseHandler extends SQLiteOpenHelper {
    // All Static variables
    // Database Version
    private static final int DATABASE_VERSION = 15;

    // Database Name
    private static final String DATABASE_NAME = "imagedb9";
    // Contacts table name
    private static final String TABLE_CONTACTS = "contacts";
    // Contacts Table Columns names
    private static final String KEY_ID = "id";
    private static final String KEY_BXDID = "bxdid";
    private static final String KEY_CREATETIME = "createtime";
    private static final String KEY_JD= "jd";
    private static final String KEY_WD = "wd";
    private static final String KEY_TYPE = "type";
    private static final String KEY_LX = "lx";
    private static final String KEY_ZT= "zt";
    private static final String KEY_dx= "dx";
    private static final String KEY_IMAGE = "image";


    public DataBaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CONTACTS_TABLE = "CREATE TABLE " + TABLE_CONTACTS + "("
                + KEY_ID + " INTEGER PRIMARY KEY," + KEY_BXDID + " VARCHAR(50),"
                + KEY_CREATETIME + " VARCHZR(50),"+ KEY_JD + " VARCHAR(50),"
                + KEY_WD + " VARCHAR(50),"+ KEY_LX + " VARCHAR(50),"
                + KEY_TYPE + " VARCHAR(50),"+ KEY_ZT + " VARCHAR(50),"+ KEY_IMAGE + " VARCHAR(300),"
                + KEY_dx + " VARCHAR(50)" + ")";
        db.execSQL(CREATE_CONTACTS_TABLE);
    }

    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CONTACTS);
        // Create tables again
        onCreate(db);
    }

    /**
     * All CRUD(Create, Read, Update, Delete) Operations
     */

    public// Adding new contact
    void addContact(Contact contact) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_BXDID, contact._bxdid);
        values.put(KEY_CREATETIME, contact._createtime);
        values.put(KEY_JD, contact._jd);
        values.put(KEY_WD, contact._wd);
        values.put(KEY_LX, contact._lx);
        values.put(KEY_TYPE, contact._type);
        values.put(KEY_ZT, contact._zt);
        values.put(KEY_IMAGE, contact._image);
        values.put(KEY_dx, contact._dx);

        // Inserting Row
        db.insert(TABLE_CONTACTS, null, values);
        db.close(); // Closing database connection
    }

    // Getting All Contacts
    public List<Contact> getAllContacts(String lx, String bxdid) {
        List<Contact> contactList = new ArrayList<Contact>();
        // Select All Query
        String selectQuery = "SELECT  * FROM contacts  where lx='"+lx+"'" + " and  bxdid='"+bxdid+"' ORDER BY id " ;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Contact contact = new Contact();
                contact.setID(Integer.parseInt(cursor.getString(0)));
                contact.setBxdid(cursor.getString(1));
                contact.setCreatetime(cursor.getString(2));
                contact.setJd(cursor.getString(3));
                contact.setWd(cursor.getString(4));
                contact.setLx(cursor.getString(5));
                contact.setType(cursor.getString(6));
                contact.setZt(cursor.getString(7));
                contact.setImage(cursor.getString(8));
                contact.setdx(cursor.getString(9));
                // Adding contact to list
                contactList.add(contact);
            } while (cursor.moveToNext());
        }
        // close inserting data from database
        db.close();
        // return contact list
        return contactList;

    }

    // Updating single contact
    public int updateContact(Contact contact) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_BXDID, contact.getBxdid());
        values.put(KEY_IMAGE, contact.getImage());

        // updating row
        return db.update(TABLE_CONTACTS, values, KEY_ID + " = ?",
                new String[] { String.valueOf(contact.getID()) });

    }

    // Deleting single contact
    public void deleteContact(Contact contact) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_CONTACTS, KEY_ID + " = ?",
                new String[] { String.valueOf(contact.getID()) });
        db.close();
    }

    public int getContactsCount(String lx,String bxdid) {
        String countQuery = "SELECT  * FROM " + TABLE_CONTACTS  + " where lx='"+lx+"'" + " and  bxdid='"+bxdid+"'" ;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int aa=cursor.getCount();
        cursor.close();
        // return count
        return aa;
    }

}