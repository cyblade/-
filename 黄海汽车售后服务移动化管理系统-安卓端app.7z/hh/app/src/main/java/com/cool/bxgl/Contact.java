package com.cool.bxgl;

public class Contact {
    boolean checkStatus = false;
    int _id;
    String _d, _bxdid, _image, _createtime, _jd, _wd, _lx, _type, _zt, _dx, name;


    public Contact() {

    }
    // constructor
    public Contact(int keyId, String bxdid, String createtime, String jd, String wd, String lx, String type, String zt, String image,String dx) {
        this.name = name;
        this.checkStatus = checkStatus;
        this._id = keyId;
        this._bxdid = bxdid;
        this._createtime = createtime;
        this._jd = jd;
        this._wd = wd;
        this._lx = lx;
        this._type = type;
        this._zt = zt;
        this._image = image;
        this._dx = dx;
    }

    public Contact(String d, String bxdid, String createtime, String jd, String wd, String lx, String type, String zt, String image,String dx) {
        this.name = name;
        this.checkStatus = checkStatus;
        this._d = d;
        this._bxdid = bxdid;
        this._createtime = createtime;
        this._jd = jd;
        this._wd = wd;
        this._lx = lx;
        this._type = type;
        this._zt = zt;
        this._image = image;
        this._dx = dx;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isCheckStatus() {
        return checkStatus;
    }

    public void setCheckStatus(boolean checkStatus) {
        this.checkStatus = checkStatus;
    }


    // getting ID
    public int getID() {
        return this._id;
    }

    public void setID(int keyId) {
        this._id = keyId;
    }

    // getting name
    public String getD() {
        return this._d;
    }

    public void setD(String d) {
        this._d = d;
    }

    public String getBxdid() {
        return this._bxdid;
    }

    public void setBxdid(String bxdid) {
        this._bxdid = bxdid;
    }

    public String getCreatetime() {
        return this._createtime;
    }

    public void setCreatetime(String createtime) {
        this._createtime = createtime;
    }

    public String getJd() {
        return this._jd;
    }

    public void setJd(String jd) {
        this._jd = jd;
    }

    public String getWd() {
        return this._wd;
    }

    public void setWd(String wd) {
        this._wd = wd;
    }

    public String getLx() {
        return this._lx;
    }

    public void setLx(String lx) {
        this._lx = lx;
    }

    public String getType() {
        return this._type;
    }

    public void setType(String type) {
        this._type = type;
    }

    public String getZt() {
        return this._zt;
    }

    public void setZt(String zt) {
        this._zt = zt;
    }

    // getting phone number
    public String getImage() {
        return this._image;
    }

    // setting phone number
    public void setImage(String image) {
        this._image = image;
    }

    public String getdx() {
        return this._dx;
    }

    public void setdx(String dx) {
        this._dx = dx;
    }

}