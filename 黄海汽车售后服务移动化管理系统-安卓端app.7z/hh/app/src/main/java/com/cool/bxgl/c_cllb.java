package com.cool.bxgl;

import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class c_cllb extends AppCompatActivity {
    public String dph1,cph1,clys1,GetEmail,dph, ReturnResult,a="1",wcid;
    public List<Map<String, Object>> listItems = new ArrayList<>();
    private RecyclerView recyclerView;
    private Handler mHandler = new Handler();



    public static String URL = "http://47.93.46.72/BxdService.asmx?op=getCarInfo";
    public static String NAMESPACE = "http://tempuri.org/";
    public static String SOAP_ACTION_Bxd = "http://tempuri.org/getCarInfo";
    public static String METHOD_NAME_Bxd = "getCarInfo";
    private ImageButton back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.c_cllb);
        wcid = getIntent().getStringExtra("wcid");
        GetEmail = getIntent().getStringExtra("username");
        dph = getIntent().getStringExtra("dph");
        recyclerView = (RecyclerView) findViewById(R.id.cllb_recyclerview);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.addItemDecoration(new c_Decoration(2));
        back = (ImageButton) findViewById(R.id.cllb_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                c_cllb.this.finish();
            }
        });
        new MyAsyncTask().execute(GetEmail,dph);
    }
    private class MyAsyncTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {

            SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME_Bxd);
            PropertyInfo infodph = new PropertyInfo();
            infodph.setName("username");
            infodph.setType(String.class);
            infodph.setValue(strings[0].toString());
            request.addProperty(infodph);

            PropertyInfo infoEmail = new PropertyInfo();
            infoEmail.setName("dph");
            infoEmail.setType(String.class);
            infoEmail.setValue(strings[1].toString());
            request.addProperty(infoEmail);

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.dotNet = true;
            envelope.setOutputSoapObject(request);
            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
            try {
                //Thread.sleep(5000);
                //  AndroidHttpTransport
                //this is the actual part that will call the webservice
                androidHttpTransport.call(SOAP_ACTION_Bxd, envelope);
                //  SoapPrimitive resultee=(SoapPrimitive)envelope.getResponse();
                // Get the SoapResult from the envelope body.
                SoapObject result = (SoapObject) envelope.bodyIn;
                ReturnResult = result.getProperty(0).toString();
            } catch (Exception e) {
                e.printStackTrace();
                return e.toString();
            }
            return ReturnResult;
        }
        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    JSONArray array = new JSONArray(result);
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);
                        dph1 = object.getString("dph");
                        cph1 = object.getString("cph");
                        clys1= object.getString("clys");
                        Map<String, Object> map = new HashMap<>();
                        map.put("wcid",wcid);
                        map.put("dph", dph1);
                        map.put("cph", cph1);
                        map.put("clys", clys1);
                        map.put("username", GetEmail);
                        listItems.add(map);
                    }
                    Message msg = new Message();
                    msg.what = 1;
                    handler.sendMessage(msg);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    public Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    //添加分割线
                    recyclerView.addItemDecoration(new DividerItemDecoration(
                            c_cllb.this, DividerItemDecoration.VERTICAL));
                    c_cllb_Adapter recy = new c_cllb_Adapter(listItems, c_cllb.this);
                    //设置布局显示格式
                    recyclerView.setLayoutManager(new LinearLayoutManager(c_cllb.this));
                    recyclerView.setAdapter(recy);
                    break;
            }
        }
    };
}