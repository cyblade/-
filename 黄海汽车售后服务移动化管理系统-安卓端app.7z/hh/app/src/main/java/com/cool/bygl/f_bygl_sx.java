package com.cool.bygl;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.Gravity;
import android.view.WindowManager;

import com.cool.bxgl.R;

public class f_bygl_sx extends Dialog {
    private Context context;
    private int resId;


    public f_bygl_sx(Context context, int resLayout) {
        this(context, 0, 0);
    }

    public f_bygl_sx(Context context, int themeResId, int resLayout) {
        super(context, themeResId);
        this.context = context;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.c_bxgl_sx);
        WindowManager m = getWindow().getWindowManager();
        Display d = m.getDefaultDisplay();
        WindowManager.LayoutParams p = getWindow().getAttributes();
        p.x = 0;
        p.y = 0;
        Point size = new Point();
        d.getSize(size);
        getWindow().setAttributes(p);
        p.gravity = Gravity.TOP | Gravity.RIGHT;


    }
}
