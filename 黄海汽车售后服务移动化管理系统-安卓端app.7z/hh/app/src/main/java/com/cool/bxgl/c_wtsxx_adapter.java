package com.cool.bxgl;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class c_wtsxx_adapter extends RecyclerView.Adapter<c_wtsxx_adapter.ViewHolder> {
    private Context context;
    public List<Map<String, Object>> list = new ArrayList<>();
    private ButtonInterface buttonInterface;
    public LayoutInflater inflater;

    public c_wtsxx_adapter(List<Map<String, Object>> list, Context context) {
        this.list = list;
        this.context = context;
        inflater = LayoutInflater.from(context);
    }

    public void buttonSetOnclick(c_wtsxx_adapter.ButtonInterface buttonInterface) {
        this.buttonInterface = buttonInterface;
    }

    public interface ButtonInterface {
        public void onclick(View view, int position);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.c_wtsxx_item, null);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }


    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        holder.fwzh.setText(list.get(position).get("服务站号").toString());
        holder.fch.setText(list.get(position).get("分厂号").toString());
        holder.wtsh.setText(list.get(position).get("委托书号").toString());
        holder.kdr.setText(list.get(position).get("开单人").toString());
        holder.cz.setText(list.get(position).get("车主").toString());
        holder.dz.setText(list.get(position).get("地址").toString());
        holder.sjh.setText(list.get(position).get("手机号").toString());
        holder.sxr.setText(list.get(position).get("送修人").toString());
        holder.sxrxb.setText(list.get(position).get("送修人性别").toString());
        holder.sxrsj.setText(list.get(position).get("送修人手机号").toString());
        holder.ldfs.setText(list.get(position).get("来电方式").toString());
        holder.khlx.setText(list.get(position).get("客户类型").toString());
        holder.yjwcrq.setText(list.get(position).get("预计完工日期").toString());
        holder.yjwgsj.setText(list.get(position).get("预计完工时间").toString());
        holder.jzrq.setText(list.get(position).get("进站日期").toString());
        holder.jzsj.setText(list.get(position).get("进站时间").toString());
        holder.kdrq.setText(list.get(position).get("开单日期").toString());
        holder.kdrq.setText(list.get(position).get("开单时间").toString());
        holder.pgrq.setText(list.get(position).get("派工日期").toString());
        holder.pgsj.setText(list.get(position).get("派工时间").toString());
        holder.kgrq.setText(list.get(position).get("开工日期").toString());
        holder.kgsj.setText(list.get(position).get("开工时间").toString());
        holder.wgrq.setText(list.get(position).get("完工日期").toString());
        holder.wgsj.setText(list.get(position).get("完工时间").toString());
        holder.wgscrq.setText(list.get(position).get("完工审查日期").toString());
        holder.wgscsj.setText(list.get(position).get("完工审查时间").toString());
        holder.jsrq.setText(list.get(position).get("结算日期").toString());
        holder.jssj.setText(list.get(position).get("结算时间").toString());
        holder.jcrq.setText(list.get(position).get("交车日期").toString());
        holder.jcsj.setText(list.get(position).get("交车时间").toString());
        holder.cp.setText(list.get(position).get("厂牌").toString());
        holder.cx.setText(list.get(position).get("车系").toString());
        holder.xh.setText(list.get(position).get("型号").toString());
        holder.cph.setText(list.get(position).get("车牌号").toString());
        holder.xslc.setText(list.get(position).get("行驶里程").toString());
        holder.clys.setText(list.get(position).get("车辆颜色").toString());
        holder.dph.setText(list.get(position).get("底牌号").toString());
        holder.fdjh.setText(list.get(position).get("发动机号").toString());
        holder.bsxh.setText(list.get(position).get("变速箱号").toString());
        holder.scrq.setText(list.get(position).get("生产日期").toString());
        holder.gcrq.setText(list.get(position).get("购车日期").toString());
        holder.sbrq.setText(list.get(position).get("首保日期").toString());
        holder.xllb.setText(list.get(position).get("修理类别").toString());
        holder.mblx.setText(list.get(position).get("免保类型").toString());
        holder.bgfs.setText(list.get(position).get("包工方式").toString());
        holder.bgf.setText(list.get(position).get("包工费").toString());
        holder.gzms.setText(list.get(position).get("故障描述").toString());
        holder.cbzd.setText(list.get(position).get("初步诊断").toString());
        holder.syyl.setText(list.get(position).get("剩余油量").toString());
        holder.ckms.setText(list.get(position).get("车况描述").toString());
        holder.pgy.setText(list.get(position).get("派工员").toString());
        holder.wgscy.setText(list.get(position).get("完工审查员").toString());
        holder.cllbItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private RelativeLayout cllbItem;
        TextView fwzh,fch,wtsh,kdr,cz,dz,sjh,sxr,sxrxb,sxrsj,ldfs,khlx,yjwcrq,yjwgsj,jzrq,jzsj,kdrq,kdsj,pgrq,pgsj,kgrq,kgsj,wgrq,wgsj,wgscrq,wgscsj,jsrq,jssj,jcrq,jcsj,cp,cx,xh,cph,xslc,clys,dph,fdjh,bsxh,scrq,gcrq,sbrq,xllb,mblx,bgfs,bgf,gzms,cbzd,syyl,ckms,pgy,wgscy;

        ViewHolder(View itemView) {
            super(itemView);
            fwzh = itemView.findViewById(R.id.wts_fwzh);
            fch = itemView.findViewById(R.id.wts_fch);
            wtsh = itemView.findViewById(R.id.wts_wtsh);
            kdr = itemView.findViewById(R.id.wts_kdr);
            cz = itemView.findViewById(R.id.wts_cz);
            dz = itemView.findViewById(R.id.wts_dz);
            sjh = itemView.findViewById(R.id.wts_sjh);
            sxr = itemView.findViewById(R.id.wts_sxr);
            sxrxb = itemView.findViewById(R.id.wts_sxrxb);
            sxrsj = itemView.findViewById(R.id.wts_sxrsj);
            ldfs = itemView.findViewById(R.id.wts_ldfs);
            khlx = itemView.findViewById(R.id.wts_khlx);
            yjwcrq = itemView.findViewById(R.id.wts_yjwcrq);
            yjwgsj = itemView.findViewById(R.id.wts_yjwgsj);
            jzrq = itemView.findViewById(R.id.wts_jzrq);
            jzsj = itemView.findViewById(R.id.wts_jzsj);
            kdrq = itemView.findViewById(R.id.wts_kdrq);
            kdsj = itemView.findViewById(R.id.wts_kdsj);
            pgrq = itemView.findViewById(R.id.wts_pgrq);
            pgsj = itemView.findViewById(R.id.wts_pgsj);
            kgrq = itemView.findViewById(R.id.wts_kgrq);
            kgsj = itemView.findViewById(R.id.wts_kgsj);
            wgrq = itemView.findViewById(R.id.wts_wgrq);
            wgsj = itemView.findViewById(R.id.wts_wgsj);
            wgscrq = itemView.findViewById(R.id.wts_wgscrq);
            wgscsj = itemView.findViewById(R.id.wts_wgscsj);
            jsrq = itemView.findViewById(R.id.wts_jsrq);
            jssj = itemView.findViewById(R.id.wts_jssj);
            jcrq = itemView.findViewById(R.id.wts_jcrq);
            jcsj = itemView.findViewById(R.id.wts_jcsj);
            cp = itemView.findViewById(R.id.wts_cp);
            cx = itemView.findViewById(R.id.wts_cx);
            xh = itemView.findViewById(R.id.wts_xh);
            cph = itemView.findViewById(R.id.wts_cph);
            xslc = itemView.findViewById(R.id.wts_xslc);
            clys = itemView.findViewById(R.id.wts_clys);
            dph = itemView.findViewById(R.id.wts_dph);
            fdjh = itemView.findViewById(R.id.wts_fdjh);
            bsxh = itemView.findViewById(R.id.wts_bsxh);
            scrq = itemView.findViewById(R.id.wts_scrq);
            gcrq = itemView.findViewById(R.id.wts_gcrq);
            sbrq = itemView.findViewById(R.id.wts_sbrq);
            xllb = itemView.findViewById(R.id.wts_xllb);
            mblx = itemView.findViewById(R.id.wts_mblx);
            bgfs = itemView.findViewById(R.id.wts_bgfs);
            bgf = itemView.findViewById(R.id.wts_bgf);
            gzms = itemView.findViewById(R.id.wts_gzms);
            cbzd = itemView.findViewById(R.id.wts_cbzd);
            syyl = itemView.findViewById(R.id.wts_syyl);
            ckms = itemView.findViewById(R.id.wts_ckms);
            pgy = itemView.findViewById(R.id.wts_pgy);
            wgscy = itemView.findViewById(R.id.wts_wgscy);
            cllbItem = itemView.findViewById(R.id.cll_item);
        }
    }
}



