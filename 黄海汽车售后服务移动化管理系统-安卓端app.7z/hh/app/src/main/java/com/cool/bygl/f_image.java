package com.cool.bygl;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.cool.bxgl.R;

import java.io.FileNotFoundException;

public class f_image extends AppCompatActivity {
    ImageView imageDetail;
    String imageId;
    public Uri aa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.d_image);


        imageId = getIntent().getStringExtra("imageid");
        aa = Uri.parse((String) imageId);
        try {
            Bitmap bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(aa));
            imageDetail = (ImageView) findViewById(R.id.imageView1);
            imageDetail.setImageBitmap(bitmap);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }


        ImageButton back = (ImageButton) findViewById(R.id.yt_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                f_image.this.finish();
            }
        });

    }
}


