package com.cool.bygl;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.location.Location;
import android.location.LocationListener;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.cool.bxgl.R;
import com.example.takevideo.record.landscapevideocamera.VideoCaptureActivity;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class f_zplb extends AppCompatActivity {
    private TextView iv_start;
    String videopath = "";
    TextView addImage, sc;
    ArrayList<Contact> imageArry = new ArrayList<Contact>();
    ContactImageAdapter imageAdapter;
    ListView dataList;
    DataBaseHandler db;
    public Uri imageUri;
    public static File tempFile, tempFile2;
    public static String URL = "http://47.93.46.72/BydService.asmx?op=AddBydFj";
    public static String NAMESPACE = "http://tempuri.org/";
    public static String SOAP_ACTION_Login = "http://tempuri.org/AddBydFj";
    public static String METHOD_NAME_Login = "AddBydFj";


    String ReturnResult, filename, filename2, size, getid, getlx, la, lt, getd = "1", getfszt, getshzt, get, type, getusername;

    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            "android.permission.READ_EXTERNAL_STORAGE",
            "android.permission.WRITE_EXTERNAL_STORAGE"};
    LocationListener mLocationListener = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.f_zplb);

        verifyStoragePermissions(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
            StrictMode.setVmPolicy(builder.build());
        }
        getfszt = getIntent().getStringExtra("fszt");
        getshzt = getIntent().getStringExtra("shzt");
        getusername = getIntent().getStringExtra("username");
        getid = getIntent().getStringExtra("id");
        getlx = getIntent().getStringExtra("lx");
        /*get = getIntent().getStringExtra("video");*/

        dataList = (ListView) findViewById(R.id.list);
        db = new DataBaseHandler(this);

        addImage = (TextView) findViewById(R.id.btnAdd);
        addImage.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (getfszt.equals("审核不通过")) {
                    Toast.makeText(f_zplb.this, "复审未通过无法照相", Toast.LENGTH_SHORT).show();
                } else {
                    if (CameraCanUseUtils.isCameraCanUse()) {
                        callCamera();
                    } else {
                        Toast.makeText(f_zplb.this, "没相机权限，请到应用程序权限管理开启权限", Toast.LENGTH_SHORT).show();
                        getAppDetailSettingIntent();
                    }
                }
            }
        });
        iv_start = (TextView) findViewById(R.id.btn_Video);
        iv_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (getfszt.equals("审核不通过")) {
                    Toast.makeText(f_zplb.this, "复审未通过无法录像", Toast.LENGTH_SHORT).show();
                    return;
                } else {
                    //    tempFile2 = new File(Environment.getExternalStorageDirectory(),
                    //           filename + ".mp4");
                    Intent intents = new Intent(f_zplb.this, VideoCaptureActivity.class);
                    intents.putExtra(VideoCaptureActivity.EXTRA_OUTPUT_FILENAME, "");
                    intents.putExtra("d", getd);
                    intents.putExtra("id", getid);
                    intents.putExtra("lx", getlx);
                    startActivityForResult(intents, 101);
                }
            }
        });
        sc = (TextView) findViewById(R.id.zplb_sc);
        sc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (int i = imageArry.size() - 1; i >= 0; i--) {
                    if (imageArry.get(i).isCheckStatus()) {
                        db.deleteContact(imageArry.get(i));
                        imageArry.remove(i);
                    }
                }
                dataList.setAdapter(imageAdapter);
                imageAdapter.notifyDataSetChanged();
            }
        });

        ImageButton back = (ImageButton) findViewById(R.id.zplb_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        SimpleDateFormat timeStampFormat2 = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss");
        filename2 = timeStampFormat2.format(new Date());
        // construct a new instance
        bind();
        binding();
    }

    protected void onDestroy() {
        super.onDestroy();
        LocationUtils.getInstance(this).removeLocationUpdatesListener();
    }

    public void bind() {
        Location location = LocationUtils.getInstance(f_zplb.this).showLocation();
        if (location != null) {
            la = String.valueOf(location.getLatitude());
            lt = String.valueOf(location.getLongitude());
        } else {
            lt = "116.681299";
            la = "39.510127";
        }
    }

    public void binding() {
        try {
            imageArry.clear();
            List<Contact> contacts = db.getAllContacts(getlx, getid);
            for (Contact cn : contacts) {
                // add contacts data in arrayList
                imageArry.add(cn);
            }
            imageAdapter = new ContactImageAdapter(this, R.layout.d_zplb_item, imageArry);
            dataList.setAdapter(imageAdapter);
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "刷新列表失败", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 101 && resultCode == Activity.RESULT_OK) {
            try {
                videopath = data.getStringExtra(VideoCaptureActivity.EXTRA_OUTPUT_FILENAME);
                type = "0";
                tempFile2 = new File(videopath);
                size = String.valueOf(tempFile2.length() / 1024) + "KB";
                String tu = file2Base64(tempFile2);
                new MyAsyncTask().execute(getusername, getid, getd, "2", lt, la, getlx, "", tu);
            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "视频上传失败", Toast.LENGTH_LONG).show();
            }
        } else if (resultCode == Activity.RESULT_CANCELED) {
            String filename = null;
            String statusMessage = getString(R.string.status_capturecancelled);
        } else if (resultCode == VideoCaptureActivity.RESULT_ERROR) {
            String filename = null;
            String statusMessage = getString(R.string.status_capturefailed);
        } else if (resultCode == RESULT_OK) {
            try {//显示照片
                Bitmap bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(imageUri));
                File file = uriToFile(imageUri, f_zplb.this);
                compressImageToFile(bitmap, file);
                //	bitmap.compress(Bitmap.CompressFormat.JPEG, 20, baos);
                size = String.valueOf(file.length() / 1024) + "KB";
                type = "1";
                String tu = encodeImage(bitmap);

                new MyAsyncTask().execute(getusername, getid, getd, "1", lt, la, getlx, "", tu);
            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "图片上传服务器的问题", Toast.LENGTH_LONG).show();
            }
        }
    }


    public static boolean hasSdcard() {
        return Environment.getExternalStorageState().equals(
                Environment.MEDIA_MOUNTED);
    }

    public static String file2Base64(File filePath) {
        FileInputStream objFileIS = null;
        try {
            objFileIS = new FileInputStream(filePath);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        ByteArrayOutputStream objByteArrayOS = new ByteArrayOutputStream();
        byte[] byteBufferString = new byte[1024];
        try {
            for (int readNum; (readNum = objFileIS.read(byteBufferString)) != -1; ) {
                objByteArrayOS.write(byteBufferString, 0, readNum);
            }
        } catch (IOException e) {

        }
        String videodata = Base64.encodeToString(objByteArrayOS.toByteArray(), Base64.DEFAULT);
        return videodata;
    }

    /**
     * open camera method
     */
    public void callCamera() {
        //獲取系統版本
        int currentapiVersion = Build.VERSION.SDK_INT;
        // 激活相机
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // 判断存储卡是否可以用，可用进行存储
        if (hasSdcard()) {
            SimpleDateFormat timeStampFormat = new SimpleDateFormat(
                    "yyyyMMddHHmmss");
            filename = timeStampFormat.format(new Date());

            tempFile = new File(Environment.getExternalStorageDirectory(),
                    filename + ".jpg");
            if (currentapiVersion < 24) {
                // 从文件中创建uri
                imageUri = Uri.fromFile(tempFile);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
            } else {
                //兼容android7.0 使用共享文件的形式
                ContentValues contentValues = new ContentValues(1);
                contentValues.put(MediaStore.Images.Media.DATA, tempFile.getAbsolutePath());
                imageUri = getApplication().getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
                videopath = imageUri.toString();
            }
        }
        // 开启一个带有返回值的Activity，请求码为PHOTO_REQUEST_CAREMA
        startActivityForResult(intent, 1);
    }

    public String encodeImage(Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        //读取图片到ByteArrayOutputStream
        bitmap.compress(Bitmap.CompressFormat.JPEG, 20, baos); //参数如果为100那么就不压缩
        byte[] bytes = baos.toByteArray();
        return Base64.encodeToString(bytes, Base64.DEFAULT);
    }


    private class MyAsyncTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {
            SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME_Login);
            PropertyInfo p_username = new PropertyInfo();
            p_username.setName("username");
            p_username.setType(String.class);
            p_username.setValue(strings[0].toString());

            request.addProperty(p_username);

            PropertyInfo p_id = new PropertyInfo();
            p_id.setName("id");
            p_id.setType(String.class);
            p_id.setValue(strings[1].toString());
            request.addProperty(p_id);

            PropertyInfo p_filename = new PropertyInfo();
            p_filename.setName("file_name");
            p_filename.setType(String.class);
            p_filename.setValue(strings[2].toString());
            request.addProperty(p_filename);

            PropertyInfo p_wjlx = new PropertyInfo();
            p_wjlx.setName("wjlx");
            p_wjlx.setType(String.class);
            p_wjlx.setValue(strings[3].toString());
            request.addProperty(p_wjlx);

            PropertyInfo p_jd = new PropertyInfo();
            p_jd.setName("jd");
            p_jd.setType(String.class);
            p_jd.setValue(strings[4].toString());
            request.addProperty(p_jd);


            PropertyInfo p_wd = new PropertyInfo();
            p_wd.setName("wd");
            p_wd.setType(String.class);
            p_wd.setValue(strings[5].toString());
            request.addProperty(p_wd);


            PropertyInfo p_gzlx = new PropertyInfo();
            p_gzlx.setName("gzlx");
            p_gzlx.setType(String.class);
            p_gzlx.setValue(strings[6].toString());
            request.addProperty(p_gzlx);

            PropertyInfo p_yzm = new PropertyInfo();
            p_yzm.setName("yzm");
            p_yzm.setType(String.class);
            p_yzm.setValue(strings[7].toString());
            request.addProperty(p_yzm);

            PropertyInfo p_tu = new PropertyInfo();
            p_tu.setName("fs");
            p_tu.setType(String.class);
            p_tu.setValue(strings[8].toString());
            request.addProperty(p_tu);

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.dotNet = true;
            envelope.setOutputSoapObject(request);
            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
            try {
                androidHttpTransport.call(SOAP_ACTION_Login, envelope);
                SoapObject result = (SoapObject) envelope.bodyIn;
                if (result != null) {
                    //Get the first property and change the label text
                    ReturnResult = result.getProperty(0).toString();
                    //    Toast.makeText(LoginActivity.this, msg, Toast.LENGTH_LONG).show();
                }
            } catch (Exception e) {
                e.printStackTrace();
                return e.toString();
            }
            return ReturnResult;
        }

        protected void onPostExecute(String result) {
            if (result.equals("success")) {
                db.addContact(new Contact(getd, getid, filename2, lt, la, getlx, type, "已发送", videopath, size));
                Toast.makeText(f_zplb.this, "上传成功", Toast.LENGTH_SHORT).show();
            } else {
                db.addContact(new Contact(getd, getid, filename2, lt, la, getlx, type, "未发送", videopath, size));
                Toast.makeText(getApplicationContext(), result, Toast.LENGTH_LONG).show();
            }
            binding();
        }
    }

    public static void compressImageToFile(Bitmap bmp, File file) {
        // 0-100 100为不压缩
        int options = 20;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        // 把压缩后的数据存放到baos中
        bmp.compress(Bitmap.CompressFormat.JPEG, options, baos);
        try {
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(baos.toByteArray());
            fos.flush();
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void verifyStoragePermissions(Activity activity) {

        try {
            //检测是否有写的权限
            int permission = ActivityCompat.checkSelfPermission(activity,
                    "android.permission.WRITE_EXTERNAL_STORAGE");
            if (permission != PackageManager.PERMISSION_GRANTED) {
                // 没有写的权限，去申请写的权限，会弹出对话框
                ActivityCompat.requestPermissions(activity, PERMISSIONS_STORAGE, REQUEST_EXTERNAL_STORAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void getAppDetailSettingIntent() {
        Intent localIntent = new Intent();
        if (Build.VERSION.SDK_INT >= 9) {
            localIntent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
            localIntent.setData(Uri.fromParts("package", this.getPackageName(), null));
        } else if (Build.VERSION.SDK_INT <= 8) {
            localIntent.setAction(Intent.ACTION_VIEW);
            localIntent.setClassName("com.android.settings", "com.android.settings.InstalledAppDetails");
            localIntent.putExtra("com.android.settings.ApplicationPkgName", this.getPackageName());
        }
        startActivity(localIntent);
    }

    public static File uriToFile(Uri uri, Context context) {
        String path = null;
        if ("file".equals(uri.getScheme())) {
            path = uri.getEncodedPath();
            if (path != null) {
                path = Uri.decode(path);
                ContentResolver cr = context.getContentResolver();
                StringBuffer buff = new StringBuffer();
                buff.append("(").append(MediaStore.Images.ImageColumns.DATA).append("=").append("'" + path + "'").append(")");
                Cursor cur = cr.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, new String[]{MediaStore.Images.ImageColumns._ID, MediaStore.Images.ImageColumns.DATA}, buff.toString(), null, null);
                int index = 0;
                int dataIdx = 0;
                for (cur.moveToFirst(); !cur.isAfterLast(); cur.moveToNext()) {
                    index = cur.getColumnIndex(MediaStore.Images.ImageColumns._ID);
                    index = cur.getInt(index);
                    dataIdx = cur.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
                    path = cur.getString(dataIdx);
                }
                cur.close();
                if (index == 0) {
                } else {
                    Uri u = Uri.parse("content://media/external/images/media/" + index);
                    System.out.println("temp uri is :" + u);
                }
            }
            if (path != null) {
                return new File(path);
            }
        } else if ("content".equals(uri.getScheme())) {
            // 4.2.2以后
            String[] proj = {MediaStore.Images.Media.DATA};
            Cursor cursor = context.getContentResolver().query(uri, proj, null, null, null);
            if (cursor.moveToFirst()) {
                int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                path = cursor.getString(columnIndex);
            }
            cursor.close();

            return new File(path);
        } else {
            //Log.i(TAG, "Uri Scheme:" + uri.getScheme());
        }
        return null;
    }

    public static Bitmap getVideoThumbnail(String filePath) {
        Bitmap bitmap = null;
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(filePath);
            bitmap = retriever.getFrameAtTime();
            int w = bitmap.getWidth();

            int h = bitmap.getHeight();

            Matrix matrix = new Matrix();

            float scaleWidth = 1;

            float scaleHeight = 2;

            matrix.postScale(scaleWidth, scaleHeight);// 利用矩阵进行缩放不会造成内存溢出

            Bitmap newbmp = Bitmap.createBitmap(bitmap, 0, 0, w, h, matrix, true);

            return newbmp;


        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (RuntimeException e) {
            e.printStackTrace();
        } finally {
            try {
                retriever.release();
            } catch (RuntimeException e) {
                e.printStackTrace();
            }
        }
        return bitmap;
    }


}