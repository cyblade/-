package com.cool.bxgl;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

public class c_wxcl extends AppCompatActivity {
    public String dph1, GetEmail, ReturnResult, a = "1",lsh;
    public ImageButton back;

    public static String URL9 = "http://47.93.46.72/BxdService.asmx?op=GetWtsClmx";
    public static String NAMESPACE9 = "http://tempuri.org/";
    public static String SOAP_ACTION9 = "http://tempuri.org/GetWtsClmx";
    public static String METHOD_NAME9 = "GetWtsClmx";

    TextView cklb,clh,clmc,sl,jldw,lly,sycx,sfqtl,czy,llrq,llsj,sfxz,bz,tlbz;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.c_wxcl);
        GetEmail = getIntent().getStringExtra("GetEmail");
        lsh = getIntent().getStringExtra("lsh");
        cklb = (TextView) findViewById(R.id.wxxm_cklb);
        clh = (TextView) findViewById(R.id.wxxm_clh);
        clmc = (TextView) findViewById(R.id.wxxm_clmc);
        sl = (TextView) findViewById(R.id.wxxm_sl);
        jldw = (TextView) findViewById(R.id.wxxm_jldw);
        lly = (TextView) findViewById(R.id.wxxm_lly);
        sycx = (TextView) findViewById(R.id.wxxm_sycx);
        sfqtl = (TextView) findViewById(R.id.wxxm_sfqtl);
        czy = (TextView) findViewById(R.id.wxxm_czy);
        llrq = (TextView) findViewById(R.id.wxxm_llrq);
        llsj = (TextView) findViewById(R.id.wxxm_llsj);
        sfxz = (TextView) findViewById(R.id.wxxm_sfxz);
        bz = (TextView) findViewById(R.id.wxxm_bz);
        tlbz = (TextView) findViewById(R.id.wxxm_tlbz);
        back = (ImageButton) findViewById(R.id.wxcl_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                c_wxcl.this.finish();
            }
        });
        new c_wxcl.MyAsyncTas().execute(GetEmail, lsh);
    }
    private class MyAsyncTas extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {

            SoapObject request = new SoapObject(NAMESPACE9, METHOD_NAME9);
            PropertyInfo infodph = new PropertyInfo();
            infodph.setName("username");
            infodph.setType(String.class);
            infodph.setValue(strings[0].toString());
            request.addProperty(infodph);

            PropertyInfo infoEmail = new PropertyInfo();
            infoEmail.setName("lsh");
            infoEmail.setType(String.class);
            infoEmail.setValue(strings[1].toString());
            request.addProperty(infoEmail);

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.dotNet = true;
            envelope.setOutputSoapObject(request);
            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL9);
            try {
                //Thread.sleep(5000);
                //  AndroidHttpTransport
                //this is the actual part that will call the webservice
                androidHttpTransport.call(SOAP_ACTION9, envelope);
                //  SoapPrimitive resultee=(SoapPrimitive)envelope.getResponse();
                // Get the SoapResult from the envelope body.
                SoapObject result = (SoapObject) envelope.bodyIn;
                ReturnResult = result.getProperty(0).toString();
            } catch (Exception e) {
                e.printStackTrace();
                return e.toString();
            }
            return ReturnResult;
        }

        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    JSONArray array = new JSONArray(result);
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);
                        cklb.setText(object.getString("出库类别"));
                        clh.setText(object.getString("材料号"));
                        clmc.setText(object.getString("材料名称"));
                        sl.setText(object.getString("数量"));
                        jldw.setText(object.getString("计量单位"));
                        lly.setText(object.getString("领料员"));
                        sycx.setText(object.getString("使用车型"));
                        sfqtl.setText(object.getString("是否前台料"));
                        czy.setText(object.getString("操作员"));
                        llrq.setText(object.getString("领料日期"));
                        llsj.setText(object.getString("领料时间"));
                        sfxz.setText(object.getString("收费性质"));
                        bz.setText(object.getString("备注"));
                        tlbz.setText(object.getString("退料标志"));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}