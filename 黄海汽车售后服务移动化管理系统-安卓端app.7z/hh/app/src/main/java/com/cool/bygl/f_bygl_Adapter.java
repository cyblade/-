package com.cool.bygl;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.cool.bxgl.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class f_bygl_Adapter extends RecyclerView.Adapter<f_bygl_Adapter.ViewHolder> {
    private Context context;
    public List<Map<String, Object>> list = new ArrayList<>();
    private ButtonInterface buttonInterface;
    public LayoutInflater inflater;

    public f_bygl_Adapter(List<Map<String, Object>> list, Context context) {
        this.list = list;
        this.context = context;
        inflater = LayoutInflater.from(context);
    }
    public void buttonSetOnclick(f_bygl_Adapter.ButtonInterface buttonInterface) {
        this.buttonInterface = buttonInterface;
    }
    public interface ButtonInterface {
        public void onclick(View view, int position);
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.f_bygl_item, null);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }
    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        holder.mid.setText(list.get(position).get("id").toString());
        holder.mdph.setText(list.get(position).get("dph").toString());
        holder.mcph.setText(list.get(position).get("cph").toString());
        holder.mshzt.setText(list.get(position).get("shzt").toString());
        holder.mfszt.setText(list.get(position).get("fszt").toString());
        holder.mcjsj.setText(list.get(position).get("create_time").toString());
        holder.mgzsm.setText(list.get(position).get("gzsm").toString());
        holder.musername.setText(list.get(position).get("username").toString());
        holder.byglItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id9 = holder.mid.getText().toString();
                String username9 = holder.musername.getText().toString();
                String shzt9 = holder.mshzt.getText().toString();
                String fszt9 = holder.mfszt.getText().toString();
                Intent intent9 = new Intent(context, f_byzp.class);
                intent9.putExtra("username", username9);
                intent9.putExtra("id", id9);
                intent9.putExtra("shzt", shzt9);
                intent9.putExtra("fszt", fszt9);
                context.startActivity(intent9);
            }
        });
        holder.id_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dph9 = holder.mdph.getText().toString();
                String username9 = holder.musername.getText().toString();
                Intent MyHomeActivity = new Intent(context, f_clxx.class);
                MyHomeActivity.putExtra("GetEmail", username9);
                MyHomeActivity.putExtra("Getdph", dph9);
                MyHomeActivity.putExtra("dph", "00000000");
                context.startActivity(MyHomeActivity);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        Button id_button;
        private RelativeLayout byglItem;
        public TextView mdph, mcph, mcjsj, mid, musername, mfszt, mshzt,mgzsm;

        ViewHolder(View itemView) {
            super(itemView);
            mdph = itemView.findViewById(R.id.byglbygl_dph);
            musername = itemView.findViewById(R.id.byglbygl_username);
            mid = itemView.findViewById(R.id.byglbygl_id);
            mcjsj = itemView.findViewById(R.id.byglbygl_cjsj);
            mcph = itemView.findViewById(R.id.byglbygl_cph);
            mfszt = itemView.findViewById(R.id.byglbygl_fszt);
            mshzt = itemView.findViewById(R.id.byglbygl_shzt);
            mgzsm = itemView.findViewById(R.id.byglbygl_gzsm);
            byglItem = itemView.findViewById(R.id.byglbygl_item);
            id_button = (Button) itemView.findViewById(R.id.ckclxx);
        }
    }
}




