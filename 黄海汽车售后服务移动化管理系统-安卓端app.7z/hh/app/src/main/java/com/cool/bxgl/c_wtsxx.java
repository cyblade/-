package com.cool.bxgl;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class c_wtsxx extends AppCompatActivity {
    public String dph1,GetEmail,ReturnResult,wtsh;
    public ImageButton back;
    private RecyclerView recyclerView;
    public List<Map<String, Object>> listItems = new ArrayList<>();

    public static String URLx = "http://47.93.46.72/BxdService.asmx?op=GetWtsMx";
    public static String NAMESPACEx = "http://tempuri.org/";
    public static String SOAP_ACTIONx = "http://tempuri.org/GetWtsMx";
    public static String METHOD_NAMEx = "GetWtsMx";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.c_wtsxx);
        GetEmail = getIntent().getStringExtra("username");
        wtsh = getIntent().getStringExtra("wtsh");
        recyclerView = (RecyclerView) findViewById(R.id.wtsxx_text);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.addItemDecoration(new c_Decoration(2));
        back = (ImageButton) findViewById(R.id.wtsxx_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                c_wtsxx.this.finish();
            }
        });
        new MyAsyncTask().execute(GetEmail,wtsh);
    }
    private class MyAsyncTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {

            SoapObject request = new SoapObject(NAMESPACEx, METHOD_NAMEx);
            PropertyInfo infoclmc = new PropertyInfo();
            infoclmc.setName("username");
            infoclmc.setType(String.class);
            infoclmc.setValue(strings[0].toString());
            request.addProperty(infoclmc);

            PropertyInfo infoEmail = new PropertyInfo();
            infoEmail.setName("wtsh");
            infoEmail.setType(String.class);
            infoEmail.setValue(strings[1].toString());
            request.addProperty(infoEmail);

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.dotNet = true;
            envelope.setOutputSoapObject(request);
            HttpTransportSE androidHttpTransport = new HttpTransportSE(URLx);
            try {
                //Thread.sleep(5000);
                //  AndroidHttpTransport
                //this is the actual part that will call the webservice
                androidHttpTransport.call(SOAP_ACTIONx, envelope);
                //  SoapPrimitive resultee=(SoapPrimitive)envelope.getResponse();
                // Get the SoapResult from the envelope body.
                SoapObject result = (SoapObject) envelope.bodyIn;
                ReturnResult = result.getProperty(0).toString();
            } catch (Exception e) {
                e.printStackTrace();
                return e.toString();
            }
            return ReturnResult;
        }
        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    JSONArray array = new JSONArray(result);
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);
                        String fwzh = object.getString("服务站号");
                        String fch = object.getString("分厂号");
                        String wtsh = object.getString("委托书号");
                        String kdr = object.getString("开单人");
                        String cz = object.getString("车主");
                        String dz = object.getString("地址");
                        String sjh = object.getString("手机号");
                        String sxr = object.getString("送修人");
                        String sxrxb = object.getString("送修人性别");
                        String sxrsj = object.getString("送修人手机号");
                        String ldfs = object.getString("来电方式");
                        String khlx = object.getString("客户类型");
                        String yjwcrq = object.getString("预计完工日期");
                        String yjwgsj = object.getString("预计完工时间");
                        String jzrq = object.getString("进站日期");
                        String jzsj = object.getString("进站时间");
                        String kdrq = object.getString("开单日期");
                        String kdsj = object.getString("开单时间");
                        String pgrq = object.getString("派工日期");
                        String pgsj = object.getString("派工时间");
                        String kgrq = object.getString("开工日期");
                        String kgsj = object.getString("开工时间");
                        String wgrq = object.getString("完工日期");
                        String wgsj = object.getString("完工时间");
                        String wgscrq = object.getString("完工审查日期");
                        String wgscsj = object.getString("完工审查时间");
                        String jsrq = object.getString("结算日期");
                        String jssj = object.getString("结算时间");
                        String jcrq = object.getString("交车日期");
                        String jcsj = object.getString("交车时间");
                        String cp = object.getString("厂牌");
                        String cx = object.getString("车系");
                        String xh = object.getString("型号");
                        String cph = object.getString("车牌号");
                        String xslc = object.getString("行驶里程");
                        String clys = object.getString("车辆颜色");
                        String dph = object.getString("底牌号");
                        String fdjh = object.getString("发动机号");
                        String bsxh = object.getString("变速箱号");
                        String scrq = object.getString("生产日期");
                        String gcrq = object.getString("购车日期");
                        String sbrq = object.getString("首保日期");
                        String xllb = object.getString("修理类别");
                        String mblx = object.getString("免保类型");
                        String bgfs = object.getString("包工方式");
                        String bgf = object.getString("包工费");
                        String gzms = object.getString("故障描述");
                        String cbzd = object.getString("初步诊断");
                        String syyl = object.getString("剩余油量");
                        String ckms = object.getString("车况描述");
                        String pgy = object.getString("派工员");
                        String wgscy = object.getString("完工审查员");
                        Map<String, Object> map = new HashMap<>();
                        map.put("服务站号", fwzh);
                        map.put("分厂号", fch);
                        map.put("委托书号", wtsh);
                        map.put("开单人", kdr);
                        map.put("车主", cz);
                        map.put("地址", dz);
                        map.put("手机号", sjh);
                        map.put("送修人", sxr);
                        map.put("送修人性别", sxrxb);
                        map.put("送修人手机号", sxrsj);
                        map.put("来电方式", ldfs);
                        map.put("客户类型", khlx);
                        map.put("预计完工日期", yjwcrq);
                        map.put("预计完工时间", yjwgsj);
                        map.put("进站日期", jzrq);
                        map.put("进站时间", jzsj);
                        map.put("开单日期", kdrq);
                        map.put("开单时间", kdsj);
                        map.put("派工日期", pgrq);
                        map.put("派工时间", pgsj);
                        map.put("开工日期", kgrq);
                        map.put("开工时间", kgsj);
                        map.put("完工日期", wgrq);
                        map.put("完工时间", wgsj);
                        map.put("完工审查日期", wgscrq);
                        map.put("完工审查时间", wgscsj);
                        map.put("结算日期", jsrq);
                        map.put("结算时间", jssj);
                        map.put("交车日期", jcrq);
                        map.put("交车时间", jcsj);
                        map.put("厂牌", cp);
                        map.put("车系", cx);
                        map.put("型号", xh);
                        map.put("车牌号", cph);
                        map.put("行驶里程", xslc);
                        map.put("车辆颜色", clys);
                        map.put("底牌号", dph);
                        map.put("发动机号", fdjh);
                        map.put("变速箱号", bsxh);
                        map.put("生产日期", scrq);
                        map.put("购车日期", gcrq);
                        map.put("首保日期", sbrq);
                        map.put("修理类别", xllb);
                        map.put("免保类型", mblx);
                        map.put("包工方式", bgfs);
                        map.put("包工费", bgf);
                        map.put("故障描述", gzms);
                        map.put("初步诊断", cbzd);
                        map.put("剩余油量", syyl);
                        map.put("车况描述", ckms);
                        map.put("派工员", pgy);
                        map.put("完工审查员", wgscy);
                        listItems.add(map);
                    }
                    recyclerView.addItemDecoration(new DividerItemDecoration(
                            c_wtsxx.this, DividerItemDecoration.VERTICAL));
                    c_wtsxx_adapter recy = new c_wtsxx_adapter(listItems, c_wtsxx.this);
                    //设置布局显示格式
                    recyclerView.setLayoutManager(new LinearLayoutManager(c_wtsxx.this));
                    recyclerView.setAdapter(recy);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}