package com.cool.bxgl;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class c_gzlb extends AppCompatActivity {
    private RecyclerView recyclerView;
    private Button iv_add,clzp;
    public TextView gzlbid,gzlbcph,gzlbdph;
    public String GetEmail,Getid,getdph,getcph,ReturnResult,ct2,gzid2,gzsm2,sxr2,spbg2,khts2,sxrdh2,wcbg2;
    public List<Map<String, Object>> listItems2 = new ArrayList<>();

    public static String URL = "http://47.93.46.72/BxdService.asmx?op=getBxdGz";
    public static String NAMESPACE = "http://tempuri.org/";
    public static String SOAP_ACTION_Bxd = "http://tempuri.org/getBxdGz";
    public static String METHOD_NAME_Bxd = "getBxdGz";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.c_gzlb);
        Getid = getIntent().getStringExtra("id");
        GetEmail = getIntent().getStringExtra("username");
        getcph = getIntent().getStringExtra("cph");
        getdph = getIntent().getStringExtra("dph");
        recyclerView = (RecyclerView) findViewById(R.id.gzlb_recyclerview);
        recyclerView.setHasFixedSize(true);
        recyclerView.addItemDecoration(new c_Decoration(2));
        recyclerView.setLayoutManager(new LinearLayoutManager(c_gzlb.this));
        gzlbid = (TextView)findViewById(R.id.gzlb_id);
        gzlbcph = (TextView)findViewById(R.id.gzlb_cph);
        gzlbdph = (TextView)findViewById(R.id.gzlb_dph);
        gzlbid.setText(Getid);
        gzlbcph.setText(getcph);
        gzlbdph.setText(getdph);
        ImageButton back = (ImageButton) findViewById(R.id.gzlb_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                c_gzlb.this.finish();
            }
        });
        iv_add = (Button) findViewById(R.id.iv_add);
        iv_add.setOnClickListener(new View.OnClickListener() {
            //@Override
            public void onClick(View v) {
                Intent intent2 = new Intent(c_gzlb.this, c_gzsm_add.class);
                intent2.putExtra("username",GetEmail);
                intent2.putExtra("id",Getid);
                intent2.putExtra("cph",getcph);
                intent2.putExtra("dph",getdph);
                startActivity(intent2);
                finish();
                //adapter.addData(list.size());
            }
        });
        clzp = (Button) findViewById(R.id.gzlb_cl);
        clzp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent3 = new Intent(c_gzlb.this, c_gzsm_clzp.class);
                intent3.putExtra("id",Getid);
                intent3.putExtra("username",GetEmail);
                startActivity(intent3);
            }
        });
        new MyAsyncTask().execute(GetEmail,Getid);
    }
    private class MyAsyncTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {
            SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME_Bxd);
            PropertyInfo infoEmail = new PropertyInfo();
            infoEmail.setName("username");
            infoEmail.setType(String.class);
            infoEmail.setValue(strings[0].toString());
            request.addProperty(infoEmail);

            PropertyInfo infost = new PropertyInfo();
            infost.setName("id");
            infost.setType(String.class);
            infost.setValue(strings[1].toString());
            request.addProperty(infost);
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.dotNet = true;
            envelope.setOutputSoapObject(request);
            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
            try {
                androidHttpTransport.call(SOAP_ACTION_Bxd, envelope);
                SoapObject result = (SoapObject) envelope.bodyIn;
                ReturnResult = result.getProperty(0).toString();
            } catch (Exception e) {
                e.printStackTrace();
                return e.toString();
            }
            return ReturnResult;
        }

        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    JSONArray array = new JSONArray(result);
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);
                        gzsm2 = object.getString("gzsm");
                        sxr2 = object.getString("sxr");
                        sxrdh2 = object.getString("sxrdh");
                        spbg2 = object.getString("spbg");
                        khts2 = object.getString("khts");
                        wcbg2 = object.getString("wcbg");
                        ct2 = object.getString("create_time");
                        gzid2 = object.getString("id");
                        String shzt2 = object.getString("shzt");
                        String fszt2 = object.getString("fszt");
                        Map<String, Object> map = new HashMap<>();
                        map.put("gzsm",gzsm2);
                        map.put("sxr",sxr2);
                        map.put("sxrdh",sxrdh2);
                        map.put("spbg",spbg2);
                        map.put("khts",khts2);
                        map.put("wcbg",wcbg2);
                        map.put("create_time",ct2);
                        map.put("id",gzid2);
                        map.put("username",GetEmail);
                        map.put("shzt",shzt2);
                        map.put("fszt",fszt2);
                        listItems2.add(map);
                    }
                    Message msg = new Message();
                    msg.what = 1;
                    handler.sendMessage(msg);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    public Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    c_gzlb_Adapter recy2 = new c_gzlb_Adapter(listItems2, c_gzlb.this);
                    recyclerView.setLayoutManager(new LinearLayoutManager(c_gzlb.this));
                    recyclerView.setAdapter(recy2);
                    break;
            }
        }
    };
}

