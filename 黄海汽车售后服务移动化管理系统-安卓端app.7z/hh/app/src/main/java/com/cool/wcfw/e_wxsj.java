package com.cool.wcfw;

import android.app.Service;
import android.content.Intent;
import android.location.Location;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.cool.bxgl.LocationUtils;
import com.cool.bxgl.R;

import java.util.Timer;
import java.util.TimerTask;

public class e_wxsj extends AppCompatActivity {
    ImageButton back;
    Timer timer;
    String la,lt,al;
    TextView jd,wd,all;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.e_wxsj);

        back = (ImageButton) findViewById(R.id.wxsj_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                e_wxsj.this.finish();
            }
        });
        timer=new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                // (1) 使用handler发送消息
                Message message=new Message();
                message.what=0;
                mHandler.sendMessage(message);
            }
        },0,3000);//每隔一秒使用handler发送一下消息,也就是每隔一秒执行一次,一直重复执行
        // (2) 使用handler处理接收到的消息



    }
    protected void onDestroy() {
        super.onDestroy();
        LocationUtils.getInstance(this).removeLocationUpdatesListener();
    }

    private Handler mHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            if(msg.what == 0){
                bind();
                jd = (TextView)findViewById(R.id.wxsj_jd);
                jd.setText(lt);
                wd = (TextView)findViewById(R.id.wxsj_wd);
                wd.setText(la);
                all = (TextView)findViewById(R.id.wxsj_hbgd);
                all.setText(al);
            }
        }
    };

    public void bind() {
        Location location = LocationUtils.getInstance(e_wxsj.this).showLocation();
        if (location != null) {
            la = String.valueOf(location.getLatitude());
            lt = String.valueOf(location.getLongitude());
            al = String.valueOf(location.getAltitude());
        } else {
            lt = "116.681299";
            la = "39.510127";
            al = "null";
        }
    }

}
