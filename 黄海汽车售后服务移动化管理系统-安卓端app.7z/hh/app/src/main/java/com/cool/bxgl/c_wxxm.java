package com.cool.bxgl;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

public class c_wxxm extends AppCompatActivity {
    public String lsh,dph1,GetEmail, ReturnResult, a = "1";
    public ImageButton back;

    public static String URL9 = "http://47.93.46.72/BxdService.asmx?op=GetWtsWxmx";
    public static String NAMESPACE9 = "http://tempuri.org/";
    public static String SOAP_ACTION9 = "http://tempuri.org/GetWtsWxmx";
    public static String METHOD_NAME9 = "GetWtsWxmx";

    public TextView gsbz,gwbh,gwmc,zgwbh,fzgwh,xllb,gzjh,gzh,gzms,cljg,bzmc,sfzx,xlg,kgrq,kgsj,wgrq,wgsj,xmxz,bz,ykjbz;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.c_wxxm);
        GetEmail = getIntent().getStringExtra("GetEmail");
        lsh = getIntent().getStringExtra("lsh");
        gsbz = (TextView) findViewById(R.id.wxxm_gsbz);
        gwbh = (TextView) findViewById(R.id.wxxm_gwbh);
        gwmc = (TextView) findViewById(R.id.wxxm_gwmc);
        zgwbh = (TextView) findViewById(R.id.wxxm_zgwbh);
        fzgwh = (TextView) findViewById(R.id.wxxm_fzgwh);
        xllb = (TextView) findViewById(R.id.wxxm_xllb);
        gzjh = (TextView) findViewById(R.id.wxxm_gzjh);
        gzh = (TextView) findViewById(R.id.wxxm_gzh);
        gzms = (TextView) findViewById(R.id.wxxm_gzms);
        cljg = (TextView) findViewById(R.id.wxxm_cljg);
        bzmc = (TextView) findViewById(R.id.wxxm_bzmc);
        sfzx = (TextView) findViewById(R.id.wxxm_sfzx);
        xlg = (TextView) findViewById(R.id.wxxm_xlg);
        kgrq = (TextView) findViewById(R.id.wxxm_kgrq);
        kgsj = (TextView) findViewById(R.id.wxxm_kgsj);
        wgrq = (TextView) findViewById(R.id.wxxm_wgrq);
        wgsj = (TextView) findViewById(R.id.wxxm_wgsj);
        xmxz = (TextView) findViewById(R.id.wxxm_xmxz);
        bz = (TextView) findViewById(R.id.wxxm_bz);
        ykjbz = (TextView) findViewById(R.id.wxxm_ykjbz);

        back = (ImageButton) findViewById(R.id.wxxm_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                c_wxxm.this.finish();
            }
        });
        new c_wxxm.MyAsyncTas().execute(GetEmail, lsh);
    }
    private class MyAsyncTas extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {

            SoapObject request = new SoapObject(NAMESPACE9, METHOD_NAME9);
            PropertyInfo infodph = new PropertyInfo();
            infodph.setName("username");
            infodph.setType(String.class);
            infodph.setValue(strings[0].toString());
            request.addProperty(infodph);

            PropertyInfo infoEmail = new PropertyInfo();
            infoEmail.setName("lsh");
            infoEmail.setType(String.class);
            infoEmail.setValue(strings[1].toString());
            request.addProperty(infoEmail);

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.dotNet = true;
            envelope.setOutputSoapObject(request);
            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL9);
            try {
                //Thread.sleep(5000);
                //  AndroidHttpTransport
                //this is the actual part that will call the webservice
                androidHttpTransport.call(SOAP_ACTION9, envelope);
                //  SoapPrimitive resultee=(SoapPrimitive)envelope.getResponse();
                // Get the SoapResult from the envelope body.
                SoapObject result = (SoapObject) envelope.bodyIn;
                ReturnResult = result.getProperty(0).toString();
            } catch (Exception e) {
                e.printStackTrace();
                return e.toString();
            }
            return ReturnResult;
        }

        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    JSONArray array = new JSONArray(result);
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);
                        gsbz.setText(object.getString("工时标准"));
                        gwbh.setText(object.getString("工位编号"));
                        gwmc.setText(object.getString("工位名称"));
                        zgwbh.setText(object.getString("主工位编号"));
                        fzgwh.setText(object.getString("辐工位编号"));
                        xllb.setText(object.getString("修理类别"));
                        gzjh.setText(object.getString("故障件号"));
                        gzh.setText(object.getString("故障号"));
                        gzms.setText(object.getString("故障描述"));
                        cljg.setText(object.getString("处理结果"));
                        bzmc.setText(object.getString("班组名称"));
                        sfzx.setText(object.getString("是否增修"));
                        xlg.setText(object.getString("修理工"));
                        kgrq.setText(object.getString("开工日期"));
                        kgsj.setText(object.getString("开工时间"));
                        wgrq.setText(object.getString("完工日期"));
                        wgsj.setText(object.getString("完工时间"));
                        xmxz.setText(object.getString("项目性质"));
                        bz.setText(object.getString("备注"));
                        ykjbz.setText(object.getString("一口价标志"));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }


}