package com.cool.bygl;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.cool.bxgl.R;

import java.util.ArrayList;

public class f_byzp extends AppCompatActivity {
    private TextView t4,e8,e9,e10,e11;
    ArrayList<Contact> imageArry = new ArrayList<Contact>();
    ContactImageAdapter imageAdapter;
    ListView dataList;
    ImageButton back;
    DataBaseHandler db;
    String getlx,getid,getd,ee,ee2,ee3,ee4,ee5,getusername,show,getfszt,getshzt;
    private RelativeLayout gzxx2,gzbw2,gzj2,rwwts2,qt2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.f_byzp);
        getid = getIntent().getStringExtra("id");
        getusername = getIntent().getStringExtra("username");
        getfszt = getIntent().getStringExtra("fszt");
        getshzt = getIntent().getStringExtra("shzt");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
            StrictMode.setVmPolicy(builder.build());
        }
        t4=(TextView)findViewById(R.id.pzlx_glsqdh2);
        e8=(TextView)findViewById(R.id.e8);
        e9=(TextView)findViewById(R.id.e9);
        e10=(TextView)findViewById(R.id.cssmm);
        e11=(TextView)findViewById(R.id.fssmm);

        if (show!=null){
            t4.setVisibility(View.VISIBLE);
            e8.setVisibility(View.VISIBLE);
            e9.setVisibility(View.VISIBLE);
        }else {
            t4.setVisibility(View.INVISIBLE);
            e8.setVisibility(View.INVISIBLE);
            e9.setVisibility(View.INVISIBLE);
        };
        e10.setText(getshzt);
        e11.setText(getfszt);

        t4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });


        dataList = (ListView) findViewById(R.id.list3);
        /**
         * create DatabaseHandler object
         */
        db = new DataBaseHandler(this);
        imageAdapter = new ContactImageAdapter(this, R.layout.d_zplb_item, imageArry);
        dataList.setAdapter(imageAdapter);

        ee = String.valueOf(db.getContactsCount("故障现象", getid));
        ee2 = String.valueOf(db.getContactsCount("故障部位",getid));
        ee3 = String.valueOf(db.getContactsCount("故障件",getid));
        ee4 = String.valueOf(db.getContactsCount("任务委托书",getid));
        ee5 = String.valueOf(db.getContactsCount("其他", getid));
        TextView num = (TextView)findViewById(R.id.pic_num_gzxx);
        TextView num2 = (TextView)findViewById(R.id.pic_num_gzbw);
        TextView num3 = (TextView)findViewById(R.id.pic_num_gzj);
        TextView num4 = (TextView)findViewById(R.id.pic_num_rwwts);
        TextView num5 = (TextView)findViewById(R.id.pic_num_qt);
        num.setText(ee);
        num2.setText(ee2);
        num3.setText(ee3);
        num4.setText(ee4);
        num5.setText(ee5);



        back = (ImageButton) findViewById(R.id.gzzp_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


        gzxx2=(RelativeLayout) findViewById(R.id.pzlx_gzxx2);
        gzxx2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(f_byzp.this,f_zplb.class);
                intent.putExtra("id",getid);
                getlx = "老化现象";
                getd = "1";
                intent.putExtra("fszt",getfszt);
                intent.putExtra("d", getd);
                intent.putExtra("lx", getlx);
                intent.putExtra("username", getusername);
                intent.putExtra("shzt",getshzt);
                intent.putExtra("show", show);
                startActivity(intent);
            }
        });
        gzbw2=(RelativeLayout) findViewById(R.id.pzlx_gzbw2);
        gzbw2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(f_byzp.this,f_zplb.class);
                intent.putExtra("id",getid);
                getlx = "保养部位";
                getd = "1";
                intent.putExtra("fszt",getfszt);
                intent.putExtra("d", getd);
                intent.putExtra("lx", getlx);
                intent.putExtra("username", getusername);
                intent.putExtra("shzt",getshzt);
                intent.putExtra("show", show);
                startActivity(intent);
            }
        });
        gzj2=(RelativeLayout) findViewById(R.id.pzlx_gzj2);
        gzj2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(f_byzp.this,f_zplb.class);
                intent.putExtra("id",getid);
                getlx = "保养件";
                getd = "1";
                intent.putExtra("fszt",getfszt);
                intent.putExtra("d", getd);
                intent.putExtra("lx", getlx);
                intent.putExtra("username", getusername);
                intent.putExtra("shzt",getshzt);
                intent.putExtra("show", show);
                startActivity(intent);
            }
        });
        rwwts2=(RelativeLayout) findViewById(R.id.pzlx_rwwts2);
        rwwts2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(f_byzp.this,f_zplb.class);
                intent.putExtra("id",getid);
                getlx = "任务委托书";
                getd = "1";
                intent.putExtra("fszt",getfszt);
                intent.putExtra("d", getd);
                intent.putExtra("lx", getlx);
                intent.putExtra("username", getusername);
                intent.putExtra("shzt",getshzt);
                intent.putExtra("show", show);
                startActivity(intent);
            }
        });
        qt2=(RelativeLayout) findViewById(R.id.pzlx_qt2);
        qt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(f_byzp.this,f_zplb.class);
                intent.putExtra("id",getid);
                getlx = "其他";
                getd = "1";
                intent.putExtra("fszt",getfszt);
                intent.putExtra("d", getd);
                intent.putExtra("lx", getlx);
                intent.putExtra("username", getusername);
                intent.putExtra("shzt",getshzt);
                intent.putExtra("show", show);
                startActivity(intent);
            }
        });

    }
}