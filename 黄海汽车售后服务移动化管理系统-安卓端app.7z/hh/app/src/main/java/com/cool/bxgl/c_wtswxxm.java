package com.cool.bxgl;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class c_wtswxxm extends AppCompatActivity {
    public String gwmc1,lsh1,xllb1,GetEmail,wtsh, ReturnResult,a="1";
    public List<Map<String, Object>> listItems = new ArrayList<>();
    private RecyclerView recyclerView;
    private Handler mHandler = new Handler();



    public static String URL = "http://47.93.46.72/BxdService.asmx?op=GetWtsWxlb";
    public static String NAMESPACE = "http://tempuri.org/";
    public static String SOAP_ACTION_Bxd = "http://tempuri.org/GetWtsWxlb";
    public static String METHOD_NAME_Bxd = "GetWtsWxlb";
    private ImageButton back;
    private Button wxcl,ck;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.c_wtswxxm);
        GetEmail = getIntent().getStringExtra("username");
        wtsh = getIntent().getStringExtra("wtsh");
        recyclerView = (RecyclerView) findViewById(R.id.wtswxxm_recyclerview);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.addItemDecoration(new c_Decoration(2));
        back = (ImageButton) findViewById(R.id.wtswxxm_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                c_wtswxxm.this.finish();
            }
        });
        wxcl = (Button) findViewById(R.id.wxxmwcl);
        wxcl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent9 = new Intent(c_wtswxxm.this, c_wtswxcl.class);
                intent9.putExtra("username",GetEmail);
                intent9.putExtra("wtsh", wtsh);
                startActivity(intent9);
                c_wtswxxm.this.finish();
            }
        });
        ck = (Button) findViewById(R.id.wxxmck);
        ck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent9 = new Intent(c_wtswxxm.this, c_wtsxx.class);
                intent9.putExtra("username",GetEmail);
                intent9.putExtra("wtsh", wtsh);
                startActivity(intent9);
            }
        });
        new MyAsyncTask().execute(GetEmail,wtsh);
    }
    private class MyAsyncTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {

            SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME_Bxd);
            PropertyInfo infodph = new PropertyInfo();
            infodph.setName("username");
            infodph.setType(String.class);
            infodph.setValue(strings[0].toString());
            request.addProperty(infodph);

            PropertyInfo infoEmail = new PropertyInfo();
            infoEmail.setName("wtsh");
            infoEmail.setType(String.class);
            infoEmail.setValue(strings[1].toString());
            request.addProperty(infoEmail);

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.dotNet = true;
            envelope.setOutputSoapObject(request);
            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
            try {
                //Thread.sleep(5000);
                //  AndroidHttpTransport
                //this is the actual part that will call the webservice
                androidHttpTransport.call(SOAP_ACTION_Bxd, envelope);
                //  SoapPrimitive resultee=(SoapPrimitive)envelope.getResponse();
                // Get the SoapResult from the envelope body.
                SoapObject result = (SoapObject) envelope.bodyIn;
                ReturnResult = result.getProperty(0).toString();
            } catch (Exception e) {
                e.printStackTrace();
                return e.toString();
            }
            return ReturnResult;
        }
        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    JSONArray array = new JSONArray(result);
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);
                        gwmc1 = object.getString("gwmc");
                        lsh1 = object.getString("lsh");
                        xllb1= object.getString("xllb");
                        Map<String, Object> map = new HashMap<>();
                        map.put("gwmc", gwmc1);
                        map.put("lsh", lsh1);
                        map.put("xllb", xllb1);
                        map.put("username", GetEmail);
                        listItems.add(map);
                    }
                    //添加分割线
                    recyclerView.addItemDecoration(new DividerItemDecoration(
                            c_wtswxxm.this, DividerItemDecoration.VERTICAL));
                    c_wtswxxm_Adapter recy = new c_wtswxxm_Adapter(listItems, c_wtswxxm.this);
                    //设置布局显示格式
                    recyclerView.setLayoutManager(new LinearLayoutManager(c_wtswxxm.this));
                    recyclerView.setAdapter(recy);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}