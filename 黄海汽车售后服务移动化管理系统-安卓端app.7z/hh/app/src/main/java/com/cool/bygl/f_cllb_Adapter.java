package com.cool.bygl;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.cool.bxgl.R;
import com.cool.bxgl.c_clxx;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class f_cllb_Adapter extends RecyclerView.Adapter<f_cllb_Adapter.ViewHolder> {
    private Context context;
    public List<Map<String,Object>>list = new ArrayList<>();
    private ButtonInterface buttonInterface;
    public LayoutInflater inflater;
    public f_cllb_Adapter(List<Map<String,Object>> list, Context context) {
        this.list=list;
        this.context = context;
        inflater=LayoutInflater.from(context);
    }
    public void buttonSetOnclick(f_cllb_Adapter.ButtonInterface buttonInterface){
        this.buttonInterface=buttonInterface;
    }
    public interface ButtonInterface{
        public void onclick(View view, int position);
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= inflater.inflate(R.layout.c_cllb_item,null);
        ViewHolder viewHolder=new ViewHolder(view);
        return viewHolder;
    }


    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        holder.mdph.setText(list.get(position).get("dph").toString());
        holder.mcph.setText(list.get(position).get("cph").toString());
        holder.mclys.setText(list.get(position).get("clys").toString());
        holder.musername.setText(list.get(position).get("username").toString());
        holder.cllbItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username9 = holder.musername.getText().toString();
                String dph9 = holder.mdph.getText().toString();
                Intent intent9 = new Intent(context, f_clxx.class);
                intent9.putExtra("GetEmail",username9);
                intent9.putExtra("Getdph", dph9);
                intent9.putExtra("dph", "00000000");
                context.startActivity(intent9);
            }
        });

    }
    @Override
    public int getItemCount() { return list.size(); }
    class ViewHolder extends RecyclerView.ViewHolder {
        private RelativeLayout cllbItem;
        public TextView mdph,mcph,mclys,musername;
        ViewHolder(View itemView) {
            super(itemView);
            mdph = itemView.findViewById(R.id.cllb_1_dph);
            mcph = itemView.findViewById(R.id.cllb_1_cph);
            mclys= itemView.findViewById(R.id.cllb_1_clys);
            musername = itemView.findViewById(R.id.cllb_un);
            cllbItem = itemView.findViewById(R.id.cllb_item);
        }
    }
}



