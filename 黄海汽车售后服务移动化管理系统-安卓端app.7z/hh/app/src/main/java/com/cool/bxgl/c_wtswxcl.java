package com.cool.bxgl;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class c_wtswxcl extends AppCompatActivity {
    public String clmc1,lsh1,cklb1,GetEmail,wtsh, ReturnResult,a="1";
    public List<Map<String, Object>> listItems = new ArrayList<>();
    private RecyclerView recyclerView;



    public static String URL = "http://47.93.46.72/BxdService.asmx?op=GetWtsCllb";
    public static String NAMESPACE = "http://tempuri.org/";
    public static String SOAP_ACTION_Bxd = "http://tempuri.org/GetWtsCllb";
    public static String METHOD_NAME_Bxd = "GetWtsCllb";
    private ImageButton back;
    private Button wxxm,ck;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.c_wtswxcl);
        GetEmail = getIntent().getStringExtra("username");
        wtsh = getIntent().getStringExtra("wtsh");
        recyclerView = (RecyclerView) findViewById(R.id.wtswxcl_recyclerview);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.addItemDecoration(new c_Decoration(2));
        back = (ImageButton) findViewById(R.id.wtswxcl_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                c_wtswxcl.this.finish();
            }
        });
        wxxm = (Button) findViewById(R.id.wxclwxxm);
        wxxm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent9 = new Intent(c_wtswxcl.this, c_wtswxxm.class);
                intent9.putExtra("username",GetEmail);
                intent9.putExtra("wtsh", wtsh);
                startActivity(intent9);
                c_wtswxcl.this.finish();
            }
        });
        ck = (Button) findViewById(R.id.wxclck);
        ck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent9 = new Intent(c_wtswxcl.this, c_wtsxx.class);
                intent9.putExtra("username",GetEmail);
                intent9.putExtra("wtsh", wtsh);
                startActivity(intent9);
                c_wtswxcl.this.finish();
            }
        });
        new MyAsyncTask().execute(GetEmail,wtsh);
    }
    private class MyAsyncTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {

            SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME_Bxd);
            PropertyInfo infoclmc = new PropertyInfo();
            infoclmc.setName("username");
            infoclmc.setType(String.class);
            infoclmc.setValue(strings[0].toString());
            request.addProperty(infoclmc);

            PropertyInfo infoEmail = new PropertyInfo();
            infoEmail.setName("wtsh");
            infoEmail.setType(String.class);
            infoEmail.setValue(strings[1].toString());
            request.addProperty(infoEmail);

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.dotNet = true;
            envelope.setOutputSoapObject(request);
            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
            try {
                //Thread.sleep(5000);
                //  AndroidHttpTransport
                //this is the actual part that will call the webservice
                androidHttpTransport.call(SOAP_ACTION_Bxd, envelope);
                //  SoapPrimitive resultee=(SoapPrimitive)envelope.getResponse();
                // Get the SoapResult from the envelope body.
                SoapObject result = (SoapObject) envelope.bodyIn;
                ReturnResult = result.getProperty(0).toString();
            } catch (Exception e) {
                e.printStackTrace();
                return e.toString();
            }
            return ReturnResult;
        }
        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    JSONArray array = new JSONArray(result);
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);
                        clmc1 = object.getString("clmc");
                        lsh1 = object.getString("lsh");
                        cklb1= object.getString("cklb");
                        Map<String, Object> map = new HashMap<>();
                        map.put("clmc", clmc1);
                        map.put("lsh", lsh1);
                        map.put("cklb", cklb1);
                        map.put("username", GetEmail);
                        listItems.add(map);
                    }
                    recyclerView.addItemDecoration(new DividerItemDecoration(
                            c_wtswxcl.this, DividerItemDecoration.VERTICAL));
                    c_wtswxcl_Adapter recy = new c_wtswxcl_Adapter(listItems, c_wtswxcl.this);
                    //设置布局显示格式
                    recyclerView.setLayoutManager(new LinearLayoutManager(c_wtswxcl.this));
                    recyclerView.setAdapter(recy);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}