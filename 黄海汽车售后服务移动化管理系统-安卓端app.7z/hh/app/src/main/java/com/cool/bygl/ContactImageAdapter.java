package com.cool.bygl;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.cool.bxgl.R;
import com.example.takevideo.record.landscapevideocamera.PlayVideo;

import java.util.ArrayList;

public class ContactImageAdapter extends ArrayAdapter<Contact> {
    Context context;
    TextView zero;
    int layoutResourceId;
    // BcardImage data[] = null;
    ArrayList<Contact> data = new ArrayList<Contact>();


    public ContactImageAdapter(Context context, int layoutResourceId, ArrayList<Contact> data) {
        super(context, layoutResourceId, data);

        this.layoutResourceId = layoutResourceId;
        this.context = context;
        this.data = data;

    }
    @Override
    public int getCount() {
        return data.size();
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View row = convertView;
        ImageHolder holder = null;
        Contact picture = data.get(position);
        if (row == null) {
            LayoutInflater inflater = ((Activity) context).getLayoutInflater();
            row = inflater.inflate(layoutResourceId, parent, false);
            row = LayoutInflater.from(context).inflate(R.layout.d_zplb_item, null);

            holder = new ImageHolder();
            holder.zplb_bxdid2 = (TextView) row.findViewById(R.id.zplb_bxdid2);
            holder.zplb_lx2 = (TextView) row.findViewById(R.id.zplb_lx2);
            holder.zplb_jd2 = (TextView) row.findViewById(R.id.zplb_jd2);
            holder.zplb_wd2 = (TextView) row.findViewById(R.id.zplb_wd2);
            holder.zplb_time2 = (TextView) row.findViewById(R.id.zplb_time2);
            holder.zplb_fszt = (TextView) row.findViewById(R.id.zplb_fszt);
            holder.zplb_wjm = (TextView) row.findViewById(R.id.zplb_wjm2);
            holder.zplb_im = (ImageView) row.findViewById(R.id.zplb_im);
            if (picture._type.equals("1")) {
                holder.pzlbItem = (RelativeLayout) row.findViewById(R.id.zplb_item);
                holder.pzlbItem.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View row) {
                        Intent My=new Intent(context,f_image.class);
                        My.putExtra("imageid",picture._image);
                        context.startActivity(My);
                    }
                });
            }else {
                holder.pzlbItem = (RelativeLayout) row.findViewById(R.id.zplb_item);
                holder.pzlbItem.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View row) {
                        Intent it2 = new Intent(context, PlayVideo.class);
                        it2.putExtra("path", picture._image);
                        context.startActivity(it2);
                    }
                });
            }



            holder.zplb_dx2 = (TextView) row.findViewById(R.id.zplb_size2);
            row.setTag(holder);
        } else {
            holder = (ImageHolder) row.getTag();
        }
        holder.zplb_bxdid2.setText(picture._bxdid);
        holder.zplb_lx2.setText(picture._lx);
        holder.zplb_jd2.setText(picture._jd);
        holder.zplb_wd2.setText(picture._wd);
        holder.zplb_time2.setText(picture._createtime);
        holder.zplb_fszt.setText(picture._zt);
        holder.zplb_dx2.setText(picture._dx);
        holder.zplb_wjm.setText(picture._image);
        Uri aa = Uri.parse((String) picture._image);
        final CheckBox cb = (CheckBox) row.findViewById(R.id.zplb_cb);
        if (data.get(position).isCheckStatus()){
            cb.setChecked(true);
        }

        cb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cb.isChecked()) {
                    data.get(position).setCheckStatus(true);
                }
                else if (cb.isEnabled()){
                    data.get(position).setCheckStatus(false);
                }
            }
        });
        try {
            if (picture._type.equals("1")) {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(context.getContentResolver(), aa);
                holder.zplb_im.setImageBitmap(bitmap);
            } else {
                holder.zplb_im.setImageResource(R.drawable.play);
            }

        } catch (Exception e) {
            System.out.println("Wrong!");
        }
        return row;
    }

    static class ImageHolder {
        RelativeLayout pzlbItem;
        TextView zplb_bxdid2;
        TextView zplb_size2;
        TextView zplb_jd2;
        TextView zplb_wd2;
        TextView zplb_time2;
        TextView zplb_fszt;
        TextView zplb_wjm;
        TextView zplb_lx2;
        ImageView zplb_im;
        TextView zplb_dx2;
    }

}

