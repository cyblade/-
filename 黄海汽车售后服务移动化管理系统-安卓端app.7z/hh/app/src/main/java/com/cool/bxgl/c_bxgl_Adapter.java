package com.cool.bxgl;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class c_bxgl_Adapter extends RecyclerView.Adapter<c_bxgl_Adapter.ViewHolder> {
    private Context context;
    public List<Map<String, Object>> list = new ArrayList<>();
    private ButtonInterface buttonInterface;
    public LayoutInflater inflater;

    public c_bxgl_Adapter(List<Map<String, Object>> list, Context context) {
        this.list = list;
        this.context = context;
        inflater = LayoutInflater.from(context);
    }
    public void buttonSetOnclick(c_bxgl_Adapter.ButtonInterface buttonInterface) {
        this.buttonInterface = buttonInterface;
    }
    public interface ButtonInterface {
        public void onclick(View view, int position);
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.c_bxgl_item, null);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }
    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        holder.mwcid.setText(list.get(position).get("wcid").toString());
        holder.mdph.setText(list.get(position).get("dph").toString());
        holder.mcph.setText(list.get(position).get("cph").toString());
        holder.mcjsj.setText(list.get(position).get("create_time").toString());
        holder.mid.setText(list.get(position).get("id").toString());
        holder.musername.setText(list.get(position).get("username").toString());
        holder.bxglItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id9 = holder.mid.getText().toString();
                String username9 = holder.musername.getText().toString();
                String dph9 = holder.mdph.getText().toString();
                String cph9 = holder.mcph.getText().toString();
                Intent intent9 = new Intent(context, c_gzlb.class);
                intent9.putExtra("username", username9);
                intent9.putExtra("id", id9);
                intent9.putExtra("dph", dph9);
                intent9.putExtra("cph", cph9);
                context.startActivity(intent9);
            }
        });
        holder.id_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String wcid9 = holder.mwcid.getText().toString();
                String dph9 = holder.mdph.getText().toString();
                String username9 = holder.musername.getText().toString();
                Intent MyHomeActivity = new Intent(context, c_clxx.class);
                MyHomeActivity.putExtra("wcid", wcid9);
                MyHomeActivity.putExtra("GetEmail", username9);
                MyHomeActivity.putExtra("Getdph", dph9);
                MyHomeActivity.putExtra("dph", "00000000");
                context.startActivity(MyHomeActivity);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        Button id_button;
        private RelativeLayout bxglItem;
        public TextView mdph, mcph, mcjsj, mid, musername, mwcid;

        ViewHolder(View itemView) {
            super(itemView);
            mwcid = itemView.findViewById(R.id.bxglbxgl_wcid);
            mdph = itemView.findViewById(R.id.bxglbxgl_dph);
            mid = itemView.findViewById(R.id.bxglbxgl_id);
            mcjsj = itemView.findViewById(R.id.bxglbxgl_cjsj);
            musername = itemView.findViewById(R.id.bxglbxgl_un);
            mcph = itemView.findViewById(R.id.bxglbxgl_cph);
            bxglItem = itemView.findViewById(R.id.bxglbxgl_item);
            id_button = (Button) itemView.findViewById(R.id.ckclxx);
        }
    }
}




