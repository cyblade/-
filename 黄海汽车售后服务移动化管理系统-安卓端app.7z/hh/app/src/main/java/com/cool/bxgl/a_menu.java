package com.cool.bxgl;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.cool.bygl.f_bygl;

public class a_menu extends AppCompatActivity {
    ImageView bygl,bxgl,wcfw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.a_menu);
        String GetEmail = getIntent().getStringExtra("GetEmail");
        bygl = (ImageView) findViewById(R.id.bxgl_bygl);
        bygl.setOnClickListener(new View.OnClickListener() {
            //@Override
            public void onClick(View v) {
                Intent intent2 = new Intent(a_menu.this, com.cool.bygl.f_bygl.class);
                intent2.putExtra("GetEmail",GetEmail);
                startActivity(intent2);
            }
        });

        bxgl = (ImageView) findViewById(R.id.bxgl_bxgl);
        bxgl.setOnClickListener(new View.OnClickListener() {
            //@Override
            public void onClick(View v) {
                Intent intent2 = new Intent(a_menu.this, c_bxgl.class);
                intent2.putExtra("GetEmail",GetEmail);
                startActivity(intent2);
            }
        });
        wcfw = (ImageView) findViewById(R.id.bxgl_wcfw);
        wcfw.setOnClickListener(new View.OnClickListener() {
            //@Override
            public void onClick(View v) {
                Intent intent2 = new Intent(a_menu.this, com.cool.wcfw.e_wcfw.class);
                intent2.putExtra("GetEmail",GetEmail);
                startActivity(intent2);
            }
        });
    }
}
