package com.cool.bxgl;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

public class c_gzsm_add extends AppCompatActivity {
    private ProgressDialog pd;
    private Button mb1;
    EditText gzsm, sxr, sxrdh;
    TextView cs, fs;
    CheckBox wcjy, spsq, khts;
    String GetEmail, Getid, mgzsm, msxr, msxrdh, mwc, msp, mkh, ReturnResult,getcph,getdph,fszt,shzt;

    /** Web Service */
    public static String URL = "http://47.93.46.72/BxdService.asmx?op=AddBxdGz";
    public static String NAMESPACE = "http://tempuri.org/";
    /** Login */
    public static String SOAP_ACTION_add = "http://tempuri.org/AddBxdGz";
    public static String METHOD_NAME_add = "AddBxdGz";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.c_gzsm_add);
        gzsm = (EditText) findViewById(R.id.gzsm_e11);
        sxr = (EditText) findViewById(R.id.add_1sxrxm);
        sxrdh = (EditText) findViewById(R.id.add_1sxrdh);
        cs = (TextView) findViewById(R.id.add_1cs);
        fs = (TextView) findViewById(R.id.add_1fs);
        fszt = fs.toString();
        shzt = cs.toString();
        wcjy = (CheckBox) findViewById(R.id.add_1wc);
        spsq = (CheckBox) findViewById(R.id.add_1sp);
        khts = (CheckBox) findViewById(R.id.add_1kh);
        Getid = getIntent().getStringExtra("id");
        GetEmail = getIntent().getStringExtra("username");
        getcph = getIntent().getStringExtra("cph");
        getdph = getIntent().getStringExtra("dph");
        mwc = "0";msp = "0";mkh = "0";
        wcjy.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    mwc = "1";
                }
            }
        });
        spsq.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    msp = "1";
                }
            }
        });
        khts.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    mkh = "1";
                }
            }
        });
        ImageButton back = (ImageButton) findViewById(R.id.gzsm_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                c_gzsm_add.this.finish();
            }
        });
        mb1=(Button)findViewById(R.id.gzsm_pzlx);
        mb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GetEmail = getIntent().getStringExtra("username");
                Getid = getIntent().getStringExtra("id");
                msxr = sxr.getText().toString();
                msxrdh = sxrdh.getText().toString();
                mgzsm = gzsm.getText().toString();
                if(msxr.isEmpty()||msxrdh.isEmpty()){
                    Toast.makeText(c_gzsm_add.this,"请输入送修人的姓名和电话", Toast.LENGTH_SHORT).show();
                }
                else{
                    new MyAsyncTask().execute(GetEmail,Getid,msxr,msxrdh,msp,mkh,mwc,mgzsm);
                }
            }
        });
    }
    private class MyAsyncTask extends AsyncTask<String,Void,String> {
        @Override
        protected String doInBackground(String... strings) {

            SoapObject request = new SoapObject(NAMESPACE,METHOD_NAME_add);

            PropertyInfo infoEmail=new PropertyInfo();
            infoEmail.setName("username");
            infoEmail.setType(String.class);
            infoEmail.setValue(strings[0].toString());
            request.addProperty(infoEmail);

            PropertyInfo info4=new PropertyInfo();
            info4.setName("bxd_id");
            info4.setType(String.class);
            info4.setValue(strings[1].toString());
            request.addProperty(info4);

            PropertyInfo infoid=new PropertyInfo();
            infoid.setName("sxr");
            infoid.setType(String.class);
            infoid.setValue(strings[2].toString());
            request.addProperty(infoid);

            PropertyInfo infost = new PropertyInfo();
            infost.setName("sxrdh");
            infost.setType(String.class);
            infost.setValue(strings[3].toString());
            request.addProperty(infost);

            PropertyInfo infoet = new PropertyInfo();
            infoet.setName("spbg");
            infoet.setType(String.class);
            infoet.setValue(strings[4].toString());
            request.addProperty(infoet);

            PropertyInfo infoyzm = new PropertyInfo();
            infoyzm.setName("khts");
            infoyzm.setType(String.class);
            infoyzm.setValue(strings[5].toString());
            request.addProperty(infoyzm);

            PropertyInfo infoindex = new PropertyInfo();
            infoindex.setName("wcbg");
            infoindex.setType(String.class);
            infoindex.setValue(strings[6].toString());
            request.addProperty(infoindex);

            PropertyInfo infosize = new PropertyInfo();
            infosize.setName("gzsm");
            infosize.setType(String.class);
            infosize.setValue(strings[7].toString());
            request.addProperty(infosize);

            PropertyInfo infos = new PropertyInfo();
            infos.setName("yzm");
            infos.setType(String.class);
            infos.setValue(null);
            request.addProperty(infosize);


            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.dotNet = true;
            envelope.setOutputSoapObject(request);

            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
            try {
                //Thread.sleep(5000);
                //  AndroidHttpTransport
                //this is the actual part that will call the webservice
                androidHttpTransport.call(SOAP_ACTION_add, envelope);
                //  SoapPrimitive resultee=(SoapPrimitive)envelope.getResponse();
                // Get the SoapResult from the envelope body.
                SoapObject result = (SoapObject) envelope.bodyIn;

                if (result != null) {
                    //Get the first property and change the label text
                    ReturnResult = result.getProperty(0).toString();
//String msg=resultee.toString();
                    //    Toast.makeText(LoginActivity.this, msg, Toast.LENGTH_LONG).show();
                }
            } catch (Exception e) {
                e.printStackTrace();
                return e.toString();
            }

            return ReturnResult;
        }
        protected void onPreExecute() {
            pd = ProgressDialog.show(c_gzsm_add.this, "", "加载中，请稍后");
        }
        protected void onPostExecute(String result) {
            pd.cancel();
            // This method is executed in the UIThread
            // with access to the result of the long running task
            if(result.equals("success")){
                Toast.makeText(c_gzsm_add.this, "上传成功", Toast.LENGTH_SHORT).show();
                Intent MyHomeActivity=new Intent(c_gzsm_add.this,c_gzsm_gzzp.class);
                MyHomeActivity.putExtra("id",Getid);
                MyHomeActivity.putExtra("username",GetEmail);
                MyHomeActivity.putExtra("fszt","未审核");
                MyHomeActivity.putExtra("shzt","未审核");
                startActivity(MyHomeActivity);
                finish();
            } else {
                Toast.makeText(getApplicationContext(), "上传失败", Toast.LENGTH_LONG).show();
            }

        }

    }
}