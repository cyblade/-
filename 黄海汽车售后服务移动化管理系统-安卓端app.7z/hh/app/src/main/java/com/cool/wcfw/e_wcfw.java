package com.cool.wcfw;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.cool.bxgl.LocationUtils;
import com.cool.bxgl.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Timer;
import java.util.TimerTask;

public class e_wcfw extends AppCompatActivity {
    private ProgressDialog pd;
    Button wxsj, wclb, wcks, kspz,wcqx,wcjs,bxd,xcpz,jspz;
    ImageButton back;
    Timer timer;
    String ReturnResult,la,lt,GetEmail,bxdid,wcid;
    TextView kssj;
    EditText wcsm, slr;
    public SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

    public static String URLjudge = "http://47.93.46.72/wcfwService.asmx?op=JudgeWcfw";
    public static String SOAP_ACTIONjudge = "http://tempuri.org/JudgeWcfw";
    public static String METHOD_NAMEjudge = "JudgeWcfw";

    public static String URL = "http://47.93.46.72/wcfwService.asmx?op=AddWcfw";
    public static String SOAP_ACTION = "http://tempuri.org/AddWcfw";
    public static String METHOD_NAME = "AddWcfw";

    public static String URLend = "http://47.93.46.72/wcfwService.asmx?op=EndWcfw";
    public static String SOAP_ACTIONend = "http://tempuri.org/EndWcfw";
    public static String METHOD_NAMEend = "EndWcfw";

    public static String URLdel = "http://47.93.46.72/wcfwService.asmx?op=DelWcfw";
    public static String SOAP_ACTIONdel = "http://tempuri.org/DelWcfw";
    public static String METHOD_NAMEdel = "DelWcfw";

    public static String URLmx = "http://47.93.46.72/wcfwService.asmx?op=AddWcdFjMx";
    public static String SOAP_ACTIONmx = "http://tempuri.org/AddWcdFjMx";
    public static String METHOD_NAMEmx = "AddWcdFjMx";
    public static String NAMESPACE = "http://tempuri.org/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.e_wcfw);
        bxdid = getIntent().getStringExtra("bxdid");
        GetEmail = getIntent().getStringExtra("GetEmail");
        new MyAsyncTaskjudge().execute(GetEmail,"");
        wcsm = (EditText) findViewById(R.id.wcsmx);
        slr = (EditText) findViewById(R.id.slr);
        wcks = (Button) findViewById(R.id.wcfw_wcks);
        kssj = (TextView) findViewById(R.id.kssj);

        wcks.setOnClickListener(new View.OnClickListener() {
            //@Override
            public void onClick(View v) {
                if (wcsm.getText().toString().isEmpty()) {
                    Toast.makeText(e_wcfw.this, "请输入外出说明", Toast.LENGTH_SHORT).show();
                }
                if (slr.getText().toString().isEmpty()) {
                    Toast.makeText(e_wcfw.this, "请输入受理人", Toast.LENGTH_SHORT).show();
                } else {
                    bind();
                    new MyAsyncTask().execute(GetEmail,lt,la,wcsm.getText().toString(),slr.getText().toString(),"");
                    final e_wcks_dialog dialog = new e_wcks_dialog(e_wcfw.this, R.layout.e_wcks_dialog);
                    dialog.show();
                    TextView tvCancel = (TextView) dialog.findViewById(R.id.wcks_cancel);
                    TextView tvOk = (TextView) dialog.findViewById(R.id.wcks_ok);
                    tvOk.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            dialog.dismiss();
                            Intent intent = new Intent(e_wcfw.this, e_zplb.class);
                            if (wcid == null){
                                wcid = "";
                            }
                            intent.putExtra("lx", "开始拍照");
                            intent.putExtra("getid", wcid);
                            intent.putExtra("username", GetEmail);
                            startActivity(intent);
                        }
                    });
                    tvCancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            dialog.dismiss();
                        }
                    });
                }
            }
        });
        wxsj = (Button) findViewById(R.id.wcfw_wxsj);
        wxsj.setOnClickListener(new View.OnClickListener() {
            //@Override
            public void onClick(View v) {
                Intent intent2 = new Intent(e_wcfw.this, e_wxsj.class);
                startActivity(intent2);
            }
        });
        wclb = (Button) findViewById(R.id.wcfw_wclb);
        wclb.setOnClickListener(new View.OnClickListener() {
            //@Override
            public void onClick(View v) {
                Intent intent2 = new Intent(e_wcfw.this, e_wclb.class);
                startActivity(intent2);
            }
        });
        back = (ImageButton) findViewById(R.id.wcfw_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        xcpz = (Button) findViewById(R.id.wcfw_xcpz);
        xcpz.setOnClickListener(new View.OnClickListener() {
            //@Override
            public void onClick(View v) {
                if (wcid == null){
                    Toast.makeText(e_wcfw.this, "请点击外出开始再拍摄照片", Toast.LENGTH_SHORT).show();
                }else{
                    Intent intent = new Intent(e_wcfw.this, e_zplb.class);
                    if (wcid == null){
                        wcid = "";
                    }
                    intent.putExtra("lx","开始拍照");
                    intent.putExtra("getid", wcid);
                    intent.putExtra("username",GetEmail);
                    startActivity(intent);
                }
            }
        });
        kspz = (Button) findViewById(R.id.wcfw_kspz);
        kspz.setOnClickListener(new View.OnClickListener() {
            //@Override
            public void onClick(View v) {
                if (wcid == null){
                    Toast.makeText(e_wcfw.this, "请点击外出开始再拍摄照片", Toast.LENGTH_SHORT).show();
                }else{
                    Intent intent = new Intent(e_wcfw.this, e_zplb.class);
                    if (wcid == null){
                        wcid = "";
                    }
                    intent.putExtra("lx","现场拍照");
                    intent.putExtra("getid", wcid);
                    intent.putExtra("username",GetEmail);
                    startActivity(intent);
                }
            }
        });
        bxd = (Button) findViewById(R.id.wcfw_sqbxd);
        bxd.setOnClickListener(new View.OnClickListener() {
            //@Override
            public void onClick(View v) {
                Intent intent = new Intent(e_wcfw.this, com.cool.bxgl.c_bxgl.class);
                if (wcid == null){
                    wcid = "";
                }
                intent.putExtra("GetEmail",GetEmail);
                intent.putExtra("wcid", wcid);
                startActivity(intent);

            }
        });
        jspz = (Button) findViewById(R.id.wcfw_jspz);
        jspz.setOnClickListener(new View.OnClickListener() {
            //@Override
            public void onClick(View v) {
                if (wcid == null){
                    Toast.makeText(e_wcfw.this, "请点击外出结束再拍摄照片", Toast.LENGTH_SHORT).show();
                }else{
                    Intent intent = new Intent(e_wcfw.this, e_zplb.class);
                    if (wcid == null){
                        wcid = "";
                    }
                    intent.putExtra("lx","结束拍照");
                    intent.putExtra("getid", wcid);
                    intent.putExtra("username",GetEmail);
                    startActivity(intent);
                }
            }
        });
        wcjs = (Button) findViewById(R.id.wcfw_wcjs);
        wcjs.setOnClickListener(new View.OnClickListener() {
            //@Override
            public void onClick(View v) {
                new Myend().execute(GetEmail,"");
                /*if (bxdid == null){
                    Toast.makeText(e_wcfw.this, "当前没有相关联的报修单，如果您确定结束请点击外出取消", Toast.LENGTH_SHORT).show();
                }else{
                    new Myend().execute(GetEmail,"");
                }*/
            }
        });
        wcqx = (Button) findViewById(R.id.wcfw_wcqx);
        wcqx.setOnClickListener(new View.OnClickListener() {
            //@Override
            public void onClick(View v) {
                final e_wcqx_dialog dialogg = new e_wcqx_dialog(e_wcfw.this, R.layout.e_wcqx_dialog);
                dialogg.show();
                TextView tvCancel = (TextView) dialogg.findViewById(R.id.wcqx_cancel);
                TextView tvOk = (TextView) dialogg.findViewById(R.id.wcqx_ok);
                tvCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialogg.dismiss();
                    }
                });
                tvOk.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        new Mydel().execute(GetEmail,"");
                        dialogg.dismiss();
                    }
                });
            }
        });
        timer=new Timer(true);
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                // (1) 使用handler发送消息
                Message message=new Message();
                message.what=0;
                mHandler.sendMessage(message);
            }
        },0,30000);//每隔一秒使用handler发送一下消息,也就是每隔一秒执行一次,一直重复执行
        // (2) 使用handler处理接收到的消息

    }
    private Handler mHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            if(msg.what == 0){
                if (wcid !=null){
                    bind();
                    new MyAsyncTask2().execute(GetEmail,"",wcid,"",lt,la);
                }

            }
        }
    };
    public void bind() {
        Location location = LocationUtils.getInstance(e_wcfw.this).showLocation();
        if (location != null) {
            la = String.valueOf(location.getLatitude());
            lt = String.valueOf(location.getLongitude());
        } else {
            lt = "116.681299";
            la = "39.510127";
        }
    }
    private class MyAsyncTaskjudge extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {

            SoapObject request = new SoapObject(NAMESPACE, METHOD_NAMEjudge);
            PropertyInfo infodph = new PropertyInfo();
            infodph.setName("username");
            infodph.setType(String.class);
            infodph.setValue(strings[0].toString());
            request.addProperty(infodph);
            PropertyInfo infoindex = new PropertyInfo();
            infoindex.setName("yzm");
            infoindex.setType(String.class);
            infoindex.setValue(strings[1].toString());
            request.addProperty(infoindex);

            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.dotNet = true;
            envelope.setOutputSoapObject(request);
            HttpTransportSE androidHttpTransport = new HttpTransportSE(URLjudge);
            try {
                //Thread.sleep(5000);
                //  AndroidHttpTransport
                //this is the actual part that will call the webservice
                androidHttpTransport.call(SOAP_ACTIONjudge, envelope);
                //  SoapPrimitive resultee=(SoapPrimitive)envelope.getResponse();
                // Get the SoapResult from the envelope body.
                SoapObject result = (SoapObject) envelope.bodyIn;
                ReturnResult = result.getProperty(0).toString();
            } catch (Exception e) {
                e.printStackTrace();
                return e.toString();
            }
            return ReturnResult;
        }

        protected void onPreExecute() {
            pd = ProgressDialog.show(e_wcfw.this, "", "加载中，请稍后");
        }
        protected void onPostExecute(String result) {
            pd.cancel();
            // This method is executed in the UIThread
            // with access to the result of the long running task
            if (result != null){
                try {
                    if(result.equals("false")){
                        Toast.makeText(e_wcfw.this, "请点击外出开始", Toast.LENGTH_SHORT).show();
                    }else{
                        JSONArray array = new JSONArray(result);
                        for (int i = 0; i < array.length(); i++) {
                            JSONObject object = array.getJSONObject(i);
                            wcsm.setText(object.getString("wcsm"));
                            wcsm.setEnabled(false);
                            wcsm.setTextColor(getResources().getColor(R.color.black));
                            slr.setText(object.getString("slr"));
                            slr.setEnabled(false);
                            slr.setTextColor(getResources().getColor(R.color.black));
                            kssj.setText(object.getString("kssj"));
                            kssj.setEnabled(false);
                            kssj.setTextColor(getResources().getColor(R.color.black));
                            wcid = object.getString("id");
                            Toast.makeText(e_wcfw.this, "已获取外出单号", Toast.LENGTH_SHORT).show();
                            wcks.setBackgroundColor(getResources().getColor(R.color.grayLite));
                            wcks.setEnabled(false);
                            wcjs.setBackgroundColor(getResources().getColor(R.color.colorAccent));
                            wcjs.setEnabled(true);
                            wcqx.setBackgroundColor(getResources().getColor(R.color.colorAccent));
                            wcqx.setEnabled(true);
                            wxsj.setBackgroundColor(getResources().getColor(R.color.colorAccent));
                            wxsj.setEnabled(true);

                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else{
                Toast.makeText(e_wcfw.this, "网络未连接", Toast.LENGTH_SHORT).show();
            }

        }
    }
    private class MyAsyncTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {

            SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
            PropertyInfo infodph = new PropertyInfo();
            infodph.setName("username");
            infodph.setType(String.class);
            infodph.setValue(strings[0].toString());
            request.addProperty(infodph);

            PropertyInfo infoEmail = new PropertyInfo();
            infoEmail.setName("ksjd");
            infoEmail.setType(String.class);
            infoEmail.setValue(strings[1].toString());
            request.addProperty(infoEmail);

            PropertyInfo infost = new PropertyInfo();
            infost.setName("kswd");
            infost.setType(String.class);
            infost.setValue(strings[2].toString());
            request.addProperty(infost);

            PropertyInfo infoet = new PropertyInfo();
            infoet.setName("wcsm");
            infoet.setType(String.class);
            infoet.setValue(strings[3].toString());
            request.addProperty(infoet);

            PropertyInfo infoyzm = new PropertyInfo();
            infoyzm.setName("slr");
            infoyzm.setType(String.class);
            infoyzm.setValue(strings[4].toString());
            request.addProperty(infoyzm);

            PropertyInfo infoindex = new PropertyInfo();
            infoindex.setName("yzm");
            infoindex.setType(String.class);
            infoindex.setValue(strings[5].toString());
            request.addProperty(infoindex);

            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.dotNet = true;
            envelope.setOutputSoapObject(request);
            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
            try {
                //Thread.sleep(5000);
                //  AndroidHttpTransport
                //this is the actual part that will call the webservice
                androidHttpTransport.call(SOAP_ACTION, envelope);
                //  SoapPrimitive resultee=(SoapPrimitive)envelope.getResponse();
                // Get the SoapResult from the envelope body.
                SoapObject result = (SoapObject) envelope.bodyIn;
                ReturnResult = result.getProperty(0).toString();
            } catch (Exception e) {
                e.printStackTrace();
                return e.toString();
            }
            return ReturnResult;
        }

        protected void onPreExecute() {
            pd = ProgressDialog.show(e_wcfw.this, "", "加载中，请稍后");
        }
        protected void onPostExecute(String result) {
            pd.cancel();
            // This method is executed in the UIThread
            // with access to the result of the long running task
            if(result.equals("success")){
                Toast.makeText(e_wcfw.this, "外出开始成功", Toast.LENGTH_SHORT).show();
                new MyAsyncTaskjudge().execute(GetEmail,"");
                Date date = new Date(System.currentTimeMillis());
                kssj.setText(simpleDateFormat.format(date));
                wxsj.setBackgroundColor(Color.parseColor("#00a3d9"));
                wxsj.setEnabled(true);
                wcks.setEnabled(false);
                wcks.setBackgroundColor(Color.parseColor("#b3b3b3"));
            }if(result.equals("failed")) {
                Toast.makeText(e_wcfw.this, "请结束此外出单后再新建外出单", Toast.LENGTH_SHORT).show();
                new MyAsyncTaskjudge().execute(GetEmail, "");
            }else {
                Toast.makeText(getApplicationContext(), "网络故障，外出开始失败", Toast.LENGTH_LONG).show();
            }
        }
    }
    private class MyAsyncTask2 extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {

            SoapObject request = new SoapObject(NAMESPACE, METHOD_NAMEmx);
            PropertyInfo infodph = new PropertyInfo();
            infodph.setName("username");
            infodph.setType(String.class);
            infodph.setValue(strings[0].toString());
            request.addProperty(infodph);

            PropertyInfo infoEmail = new PropertyInfo();
            infoEmail.setName("yzm");
            infoEmail.setType(String.class);
            infoEmail.setValue(strings[1].toString());
            request.addProperty(infoEmail);

            PropertyInfo infost = new PropertyInfo();
            infost.setName("wcfw_id");
            infost.setType(String.class);
            infost.setValue(strings[2].toString());
            request.addProperty(infost);

            PropertyInfo infoet = new PropertyInfo();
            infoet.setName("bxd_id");
            infoet.setType(String.class);
            infoet.setValue(strings[3].toString());
            request.addProperty(infoet);

            PropertyInfo infoyzm = new PropertyInfo();
            infoyzm.setName("jd");
            infoyzm.setType(String.class);
            infoyzm.setValue(strings[4].toString());
            request.addProperty(infoyzm);

            PropertyInfo infoindex = new PropertyInfo();
            infoindex.setName("wd");
            infoindex.setType(String.class);
            infoindex.setValue(strings[5].toString());
            request.addProperty(infoindex);

            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.dotNet = true;
            envelope.setOutputSoapObject(request);
            HttpTransportSE androidHttpTransport = new HttpTransportSE(URLmx);
            try {
                //Thread.sleep(5000);
                //  AndroidHttpTransport
                //this is the actual part that will call the webservice
                androidHttpTransport.call(SOAP_ACTIONmx, envelope);
                //  SoapPrimitive resultee=(SoapPrimitive)envelope.getResponse();
                // Get the SoapResult from the envelope body.
                SoapObject result = (SoapObject) envelope.bodyIn;
                ReturnResult = result.getProperty(0).toString();
            } catch (Exception e) {
                e.printStackTrace();
                return e.toString();
            }
            return ReturnResult;
        }

        protected void onPreExecute() {

        }
        protected void onPostExecute(String result) {
            // This method is executed in the UIThread
            // with access to the result of the long running task
            if(result.equals("success")){
                Toast.makeText(e_wcfw.this, "上传明细成功", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getApplicationContext(), "上传明细失败", Toast.LENGTH_LONG).show();
            }
        }
    }
    private class Myend extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {
            SoapObject request = new SoapObject(NAMESPACE, METHOD_NAMEend);
            PropertyInfo infodph = new PropertyInfo();
            infodph.setName("username");
            infodph.setType(String.class);
            infodph.setValue(strings[0].toString());
            request.addProperty(infodph);

            PropertyInfo infoEmail = new PropertyInfo();
            infoEmail.setName("yzm");
            infoEmail.setType(String.class);
            infoEmail.setValue(strings[1].toString());
            request.addProperty(infoEmail);

            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.dotNet = true;
            envelope.setOutputSoapObject(request);
            HttpTransportSE androidHttpTransport = new HttpTransportSE(URLend);
            try {
                //Thread.sleep(5000);
                //  AndroidHttpTransport
                //this is the actual part that will call the webservice
                androidHttpTransport.call(SOAP_ACTIONend, envelope);
                //  SoapPrimitive resultee=(SoapPrimitive)envelope.getResponse();
                // Get the SoapResult from the envelope body.
                SoapObject result = (SoapObject) envelope.bodyIn;
                ReturnResult = result.getProperty(0).toString();
            } catch (Exception e) {
                e.printStackTrace();
                return e.toString();
            }
            return ReturnResult;
        }

        protected void onPreExecute() {

        }
        protected void onPostExecute(String result) {
            // This method is executed in the UIThread
            // with access to the result of the long running task
            if(result.equals("true")){
                Toast.makeText(e_wcfw.this, "外出结束成功，辛苦了！", Toast.LENGTH_SHORT).show();
                wcks.setBackgroundColor(getResources().getColor(R.color.colorAccent));
                wcks.setEnabled(true);
                wxsj.setBackgroundColor(getResources().getColor(R.color.grayLite));
                wxsj.setEnabled(false);
                wcjs.setBackgroundColor(getResources().getColor(R.color.grayLite));
                wcjs.setEnabled(false);
                wcqx.setBackgroundColor(getResources().getColor(R.color.grayLite));
                wcqx.setEnabled(false);
                wcsm.setText("");
                wcsm.setEnabled(true);
                slr.setText("");
                slr.setEnabled(true);
                kssj.setText("");
                wcid = null;
            }else if(result.equals("false")){
                Toast.makeText(getApplicationContext(), "请点击外出开始", Toast.LENGTH_LONG).show();
            }else{
                Toast.makeText(getApplicationContext(), "网络故障，外出结束失败", Toast.LENGTH_LONG).show();
            }
        }
    }
    private class Mydel extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {

            SoapObject request = new SoapObject(NAMESPACE, METHOD_NAMEdel);
            PropertyInfo infodph = new PropertyInfo();
            infodph.setName("username");
            infodph.setType(String.class);
            infodph.setValue(strings[0].toString());
            request.addProperty(infodph);

            PropertyInfo infoEmail = new PropertyInfo();
            infoEmail.setName("yzm");
            infoEmail.setType(String.class);
            infoEmail.setValue(strings[1].toString());
            request.addProperty(infoEmail);

            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.dotNet = true;
            envelope.setOutputSoapObject(request);
            HttpTransportSE androidHttpTransport = new HttpTransportSE(URLdel);
            try {
                //Thread.sleep(5000);
                //  AndroidHttpTransport
                //this is the actual part that will call the webservice
                androidHttpTransport.call(SOAP_ACTIONdel, envelope);
                //  SoapPrimitive resultee=(SoapPrimitive)envelope.getResponse();
                // Get the SoapResult from the envelope body.
                SoapObject result = (SoapObject) envelope.bodyIn;
                ReturnResult = result.getProperty(0).toString();
            } catch (Exception e) {
                e.printStackTrace();
                return e.toString();
            }
            return ReturnResult;
        }

        protected void onPreExecute() {

        }
        protected void onPostExecute(String result) {
            // This method is executed in the UIThread
            // with access to the result of the long running task
            if(result.equals("true")){
                Toast.makeText(e_wcfw.this, "外出取消成功", Toast.LENGTH_SHORT).show();
                wcks.setBackgroundColor(getResources().getColor(R.color.colorAccent));
                wcks.setEnabled(true);
                wxsj.setBackgroundColor(getResources().getColor(R.color.grayLite));
                wxsj.setEnabled(false);
                wcjs.setBackgroundColor(getResources().getColor(R.color.grayLite));
                wcjs.setEnabled(false);
                wcqx.setBackgroundColor(getResources().getColor(R.color.grayLite));
                wcqx.setEnabled(false);
                wcsm.setText("");
                wcsm.setEnabled(true);
                slr.setText("");
                slr.setEnabled(true);
                kssj.setText("");
                wcid = null;
            }else if(result.equals("false")){
                Toast.makeText(getApplicationContext(), "请点击外出开始", Toast.LENGTH_LONG).show();
            }else{
                Toast.makeText(getApplicationContext(), "网络故障，外出取消失败", Toast.LENGTH_LONG).show();
            }
        }
    }
}
