package com.cool.bxgl;

import android.content.Intent;
import android.os.Build;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;


public class c_gzsm_clzp extends AppCompatActivity {
    ArrayList<Contact> imageArry = new ArrayList<Contact>();
    ContactImageAdapter imageAdapter;
    ListView dataList;
    private static final int CAMERA_REQUEST = 1;
    private static final int PICK_FROM_GALLERY = 2;
    DataBaseHandler db;
    String size, ee, ee2, ee3;
    SimpleDateFormat simpleDateFormat;
    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            "android.permission.READ_EXTERNAL_STORAGE",
            "android.permission.WRITE_EXTERNAL_STORAGE"};
    private TextView t1;
    private TextView t2;
    ImageButton back;
    String getlx, getid, getd, getusername;
    private RelativeLayout clcp2, lcb2, clmp2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.c_gzsm_clzp);
        getid = getIntent().getStringExtra("id");
        getusername = getIntent().getStringExtra("username");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
            StrictMode.setVmPolicy(builder.build());
        }
        dataList = (ListView) findViewById(R.id.list2);
        /**
         * create DatabaseHandler object
         */
        db = new DataBaseHandler(this);


        imageAdapter = new ContactImageAdapter(this, R.layout.d_zplb_item, imageArry);
        dataList.setAdapter(imageAdapter);

        ee = String.valueOf(db.getContactsCount("车辆车牌", getid));
        ee2 = String.valueOf(db.getContactsCount("里程表", getid));
        ee3 = String.valueOf(db.getContactsCount("车辆铭牌", getid));
        TextView num = (TextView) findViewById(R.id.pic_num_clcp);
        TextView num2 = (TextView) findViewById(R.id.pic_num_lcb);
        TextView num3 = (TextView) findViewById(R.id.pic_num_clmp);
        num.setText(ee);
        num2.setText(ee2);
        num3.setText(ee3);
        back = (ImageButton) findViewById(R.id.clzp_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        clcp2 = (RelativeLayout) findViewById(R.id.pzlx_clcp);
        clcp2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(c_gzsm_clzp.this, d_zplb.class);
                intent.putExtra("id", getid);
                getlx = "车辆车牌";
                getd = "0";
                intent.putExtra("d", getd);
                intent.putExtra("lx", getlx);
                intent.putExtra("username", getusername);
                intent.putExtra("fszt", "");
                intent.putExtra("shzt", "");
                intent.putExtra("show", "");
                startActivity(intent);
                finish();
            }
        });
        lcb2 = (RelativeLayout) findViewById(R.id.pzlx_lcb);
        lcb2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(c_gzsm_clzp.this, d_zplb.class);
                intent.putExtra("id", getid);
                getlx = "里程表";
                getd = "0";
                intent.putExtra("d", getd);
                intent.putExtra("lx", getlx);
                intent.putExtra("username", getusername);
                intent.putExtra("fszt", "");
                intent.putExtra("shzt", "");
                intent.putExtra("show", "");
                startActivity(intent);
                finish();
            }
        });
        clmp2 = (RelativeLayout) findViewById(R.id.pzlx_clmp);
        clmp2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(c_gzsm_clzp.this, d_zplb.class);
                intent.putExtra("id", getid);
                getlx = "车辆铭牌";
                getd = "0";
                intent.putExtra("d", getd);
                intent.putExtra("lx", getlx);
                intent.putExtra("username", getusername);
                intent.putExtra("fszt", "");
                intent.putExtra("shzt", "");
                intent.putExtra("show", "");
                startActivity(intent);
                finish();
            }
        });
    }
}