package com.cool.bxgl;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import q.rorbin.qrefreshlayout.QRefreshLayout;
import q.rorbin.qrefreshlayout.listener.RefreshHandler;
import q.rorbin.qrefreshlayout.widget.material.MaterialBlackHeaderView;


public class c_bxgl extends AppCompatActivity {
    private QRefreshLayout refreshLayout;
    public String dph1, cph1, ct1, id1, GetEmail, kssjStr, jssjStr, sizeStr, ReturnResult, dph, p1, p2,wcid;
    public int indexStr;
    public List<Map<String, Object>> listItems = new ArrayList<>();
    private RecyclerView recyclerView;
    int mYear, mMonth, mDay;
    Button btn, btn2, btncs, cjbxd, sx , sx1;
    TextView textView1, textView2, dateDisplay, dateDisplay2, tv1, tv2;
    final int DATE_DIALOG = 1;
    final int DATE_DIALOG2 = 2;
    private Handler mHandler = new Handler();
    private ProgressDialog pd;
    public SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
    public SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-M-d");


    public static String URL = "http://47.93.46.72/BxdService.asmx?op=getBxd";
    public static String NAMESPACE = "http://tempuri.org/";
    public static String SOAP_ACTION_Bxd = "http://tempuri.org/getBxd";
    public static String METHOD_NAME_Bxd = "getBxd";


    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.c_bxgl);

        EditText mdph = (EditText) findViewById(R.id.et1);
        GetEmail = getIntent().getStringExtra("GetEmail");
        wcid = getIntent().getStringExtra("wcid");
        if (wcid == null){
            wcid = "";
        }
        recyclerView = (RecyclerView) findViewById(R.id.bxgl_recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.addItemDecoration(new c_Decoration(2));
        refreshLayout = (QRefreshLayout) findViewById(R.id.refreshlayout);
        refreshLayout.setHeaderView(new MaterialBlackHeaderView(this));
        refreshLayout.setLoadMoreEnable(true);
        btn = (Button) findViewById(R.id.date1);
        btn2 = (Button) findViewById(R.id.date2);
        textView1 = (TextView) findViewById(R.id.date1);
        textView2 = (TextView) findViewById(R.id.date2);
        tv1 = (TextView) findViewById(R.id.date3);
        tv2 = (TextView) findViewById(R.id.date4);
        final Calendar ca = Calendar.getInstance();
        mYear = ca.get(Calendar.YEAR);
        mMonth = ca.get(Calendar.MONTH);
        mDay = ca.get(Calendar.DAY_OF_MONTH);

        Date date = new Date(System.currentTimeMillis());
        Date date2 = new Date(System.currentTimeMillis());
        textView1.setText(simpleDateFormat.format(date));
        textView2.setText(simpleDateFormat.format(date2));
        tv1.setText(format.format(date));
        tv2.setText(format.format(date2));
        dateDisplay = (TextView) findViewById(R.id.date1);
        dateDisplay2 = (TextView) findViewById(R.id.date2);
        kssjStr = tv1.getText().toString() + "000000";
        jssjStr = tv2.getText().toString() + "235959";
        indexStr = 2;
        ImageButton back = (ImageButton) findViewById(R.id.bxgl_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                c_bxgl.this.finish();
            }
        });
        refreshLayout.setRefreshHandler(new RefreshHandler() {
            @Override
            public void onRefresh(QRefreshLayout refresh) {
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        listItems.clear();
                        dph = mdph.getText().toString();
                        indexStr = 1;
                        sizeStr = "9";
                        new c_bxgl.MyAsyncTask().execute(GetEmail, kssjStr, jssjStr, String.valueOf(indexStr), sizeStr, dph);
                        if (dph1!=null){
                            recyclerView.getAdapter().notifyDataSetChanged();
                        }
                        refreshLayout.refreshComplete();
                    }
                }, 0);
            }
            @Override
            public void onLoadMore(QRefreshLayout refresh) {
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        dph = mdph.getText().toString();
                        sizeStr = "9";
                        indexStr++;
                        new c_bxgl.MyAsyncTask().execute(GetEmail, kssjStr, jssjStr, String.valueOf(indexStr), sizeStr, dph);
                        if (dph1!=null){
                            recyclerView.getAdapter().notifyDataSetChanged();
                        }
                        refreshLayout.loadMoreComplete();
                    }
                }, 50);
            }
        });

        listItems = new ArrayList<>();
        btncs = (Button) findViewById(R.id.bxgl_cs);
        btncs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listItems.clear();
                dph = mdph.getText().toString();
                indexStr = 1;
                sizeStr = "9";
                new c_bxgl.MyAsyncTask().execute(GetEmail, kssjStr, jssjStr, String.valueOf(indexStr), sizeStr, dph);
                if (dph1!=null){
                    recyclerView.getAdapter().notifyDataSetChanged();
                }
            }
        });
//      调用按钮返回事件回调的方法
        cjbxd = findViewById(R.id.cjbxd);
        cjbxd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final c_bxgl_dialog dialog = new c_bxgl_dialog(c_bxgl.this, R.layout.c_bxgl_dialog);
                dialog.show();
                TextView tvCancel = (TextView) dialog.findViewById(R.id.cancel);
                TextView tvOk = (TextView) dialog.findViewById(R.id.ok);
                EditText mdph = (EditText) dialog.findViewById(R.id.bxd_dph);
                tvOk.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String dph3 = mdph.getText().toString();
                        if (dph3.length() < 8) {
                            Toast.makeText(getApplicationContext(), "请输入八位底盘号!", Toast.LENGTH_LONG).show();
                        } else {
                            dialog.dismiss();
                            Intent intent = new Intent(c_bxgl.this, c_cllb.class);
                            intent.putExtra("wcid",wcid);
                            intent.putExtra("dph", dph3);
                            intent.putExtra("username", GetEmail);
                            startActivity(intent);
                            finish();
                        }
                    }
                });
                tvCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
            }
        });
        sx = findViewById(R.id.buttonsx);
        sx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final c_bxgl_sx d = new c_bxgl_sx(c_bxgl.this, R.layout.c_bxgl_sx);
                d.show();
                sx1 = (Button)d.findViewById(R.id.sx1);
                sx1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Toast.makeText(c_bxgl.this, "需要webservice", Toast.LENGTH_SHORT).show();
                    }
                });

            }
        });

        btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                showDialog(1);
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                showDialog(2);
            }
        });
        listItems.clear();
        dph = mdph.getText().toString();
        indexStr= 1;
        sizeStr = "9";
        new c_bxgl.MyAsyncTask().execute(GetEmail, kssjStr, jssjStr, String.valueOf(indexStr), sizeStr, dph);
        if (dph1!=null){
            recyclerView.getAdapter().notifyDataSetChanged();
        }
    }


    private class MyAsyncTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {

            SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME_Bxd);
            PropertyInfo infodph = new PropertyInfo();
            infodph.setName("dph");
            infodph.setType(String.class);
            infodph.setValue(strings[5].toString());
            request.addProperty(infodph);

            PropertyInfo infoEmail = new PropertyInfo();
            infoEmail.setName("username");
            infoEmail.setType(String.class);
            infoEmail.setValue(strings[0].toString());
            request.addProperty(infoEmail);

            PropertyInfo infost = new PropertyInfo();
            infost.setName("start_time");
            infost.setType(String.class);
            infost.setValue(strings[1].toString());
            request.addProperty(infost);

            PropertyInfo infoet = new PropertyInfo();
            infoet.setName("end_time");
            infoet.setType(String.class);
            infoet.setValue(strings[2].toString());
            request.addProperty(infoet);

            PropertyInfo infoyzm = new PropertyInfo();
            infoyzm.setName("yzm");
            infoyzm.setType(String.class);
            infoyzm.setValue(null);
            request.addProperty(infoyzm);

            PropertyInfo infoindex = new PropertyInfo();
            infoindex.setName("PageIndex");
            infoindex.setType(String.class);
            infoindex.setValue(strings[3].toString());
            request.addProperty(infoindex);

            PropertyInfo infosize = new PropertyInfo();
            infosize.setName("PageSize");
            infosize.setType(String.class);
            infosize.setValue(strings[4].toString());
            request.addProperty(infosize);

            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.dotNet = true;
            envelope.setOutputSoapObject(request);
            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
            try {
                //Thread.sleep(5000);
                //  AndroidHttpTransport
                //this is the actual part that will call the webservice
                androidHttpTransport.call(SOAP_ACTION_Bxd, envelope);
                //  SoapPrimitive resultee=(SoapPrimitive)envelope.getResponse();
                // Get the SoapResult from the envelope body.
                SoapObject result = (SoapObject) envelope.bodyIn;
                ReturnResult = result.getProperty(0).toString();
            } catch (Exception e) {
                e.printStackTrace();
                return e.toString();
            }
            return ReturnResult;
        }

        protected void onPreExecute() {
            pd = ProgressDialog.show(c_bxgl.this, "", "加载中，请稍后");
        }
        protected void onPostExecute(String result) {
            pd.cancel();
            if (result != null) {
                try {
                    JSONArray array = new JSONArray(result);
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);
                        dph1 = object.getString("dph");
                        cph1 = object.getString("cph");
                        ct1 = object.getString("create_time");
                        id1 = object.getString("id");
                        Map<String, Object> map = new HashMap<>();
                        map.put("wcid", wcid);
                        map.put("dph", dph1);
                        map.put("cph", cph1);
                        map.put("create_time", ct1);
                        map.put("username", GetEmail);
                        map.put("id", id1);
                        listItems.add(map);
                    }
                    c_bxgl_Adapter recy = new c_bxgl_Adapter(listItems, c_bxgl.this);
                    recyclerView.setLayoutManager(new LinearLayoutManager(c_bxgl.this));
                    recyclerView.setAdapter(recy);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case DATE_DIALOG:
                return new DatePickerDialog(this, mdateListener, mYear, mMonth, mDay);

            case DATE_DIALOG2:
                return new DatePickerDialog(this, mdateListener2, mYear, mMonth, mDay);

        }
        return null;
    }

    /**
     * 设置日期 利用StringBuffer追加
     */
    public void display() {
        dateDisplay.setText(new StringBuffer().append(mYear).append("-").append(mMonth + 1).append("-").append(mDay).append(" "));
        ParsePosition pos = new ParsePosition(0);
        String s1 =  dateDisplay.getText().toString();
        Date d1 = simpleDateFormat.parse(s1, pos);
        p1 = format.format(d1);
        kssjStr = p1 + "000000";




    }

    public void display2() {
        dateDisplay2.setText(new StringBuffer().append(mYear).append("-").append(mMonth + 1).append("-").append(mDay).append(" "));
        ParsePosition pos = new ParsePosition(0);
        String s2 = dateDisplay2.getText().toString();
        Date d2 = simpleDateFormat.parse(s2, pos);
        p2 = format.format(d2);
        jssjStr = p2 + "235959";
    }

    private DatePickerDialog.OnDateSetListener mdateListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            mYear = year;
            mMonth = monthOfYear;
            mDay = dayOfMonth;
            display();
        }
    };
    private DatePickerDialog.OnDateSetListener mdateListener2 = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            mYear = year;
            mMonth = monthOfYear;
            mDay = dayOfMonth;
            display2();
        }
    };
}